# The AI Visibility Skill Pack for Dentists

**8 AI skills that help ChatGPT, Google and Claude find, trust and recommend your dental practice.**

From Patrick Hounsell, Co-CEO of AscendPoint Agency, home of SERP Dental. Built from 8 of our AI search webinars and our work with 300+ dental practices.

---

## What's inside

| # | Skill | What it does for you | Time |
|---|---|---|---|
| 1 | **AI Visibility Audit** | Scores how often AI recommends you (presence, position, impact), names who it recommends instead, and builds your 90-day plan | 30 min |
| 2 | **AI Bot Access** | Checks if your website is blocking ChatGPT and other AI bots, then writes a fixed robots.txt and a new llms.txt | 5 min |
| 3 | **Answer-First Service Pages** | Rewrites your implant, Invisalign or emergency page so AI can quote it, with FAQs | 20 min per page |
| 4 | **Schema + NAP Check** | Builds your practice schema and finds every place your name, address, phone or hours don't match | 15 min |
| 5 | **Weekly Google Business Profile Posts** | Drafts two GBP posts a week in your voice, ready for your office manager to approve | 5 min a week |
| 6 | **Review Engine** | Ask-every-patient scripts, the two-hour review text, and HIPAA-safe replies to every review | 10 min a week |
| 7 | **AI Authority Builder** | Press releases, an original-stats page and expert forum answers that AI trusts | 1 hour a month |
| 8 | **Positioning 2x2** | Compares your website with nearby practices and finds the message only you can own | 20 min |

Start with #2 (five minutes) and #1. They tell you where to spend the rest of your time.

---

## Install in Claude (recommended)

1. Open **claude.ai** (or the Claude desktop app) and go to **Customize > Skills** (claude.ai/customize/skills).
2. Click **+** / **Upload skill**, and upload one ZIP from the **For-Claude** folder. Repeat for each skill you want. Upload the ZIP files as they are; do not unzip them.
3. Turn each skill on. Make sure **Code execution** is enabled in Settings > Capabilities (three skills run small calculation scripts).
4. Start a new chat and ask in plain English, for example:
   - "Is my website blocking ChatGPT? It's www.mypractice.com"
   - "Run an AI visibility audit for my practice in Plano, TX"
   - "Rewrite my dental implants page so AI can quote it"
   - "Draft this week's Google Business Profile posts"

Claude picks the right skill automatically.

## Use in ChatGPT

- **ChatGPT Business or Enterprise** (with Skills turned on by your admin): open **Plugins > Skills** in the sidebar and upload the same ZIP files from the **For-Claude** folder.
- **Any ChatGPT plan with Projects or custom GPTs**: open the **For-ChatGPT** folder and follow `HOW-TO-USE-IN-CHATGPT.md`. You paste one set of instructions and upload eight playbook files. Takes about three minutes.

Gemini and other assistants: use the For-ChatGPT files the same way (Gemini "Gems" accept instructions and files).

---

## Three rules we follow (and so do these skills)

1. **No patient information in AI tools.** Never paste patient names, charts or anything that identifies a patient. The skills only ever ask for de-identified, aggregate numbers.
2. **A person approves everything** before it goes on your website, Google profile or social media.
3. **No made-up facts.** The skills mark anything they could not verify with `[CONFIRM]`.

These skills give general marketing guidance, not legal or compliance advice.

---

## Want us to run it for you?

In a free strategy session we review your Google rankings, your AI visibility and your website, and you keep the plan whether or not you work with us.
**Book a free strategy session:** https://go.serpdental.com/schedule-strategy-session?utm_source=aeo-skill-pack&utm_medium=download&utm_campaign=linkedin-aeo-skills&utm_content=readme

**Watch the AI search webinars these skills came from:** https://www.youtube.com/@SERPDental

**Follow AscendPoint Agency on LinkedIn** for new skills as we build them: https://www.linkedin.com/company/ascendpoint-agency/

© 2026 AscendPoint Agency. Free to use in your own practice. Please don't resell it.
