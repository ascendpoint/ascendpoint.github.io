# How to use the skill pack in ChatGPT (about 3 minutes)

## Option A: ChatGPT Business or Enterprise with Skills turned on

Open the sidebar, go to **Plugins > Skills**, and upload the ZIP files from the **For-Claude** folder (they use the same open skill format). If you don't see Skills, your workspace admin can turn them on, or use Option B.

## Option B: a ChatGPT Project (works on any plan with Projects)

1. In ChatGPT, click **New project** and name it "AI Visibility Copilot".
2. Open the project's **Instructions** and paste everything in `INSTRUCTIONS.txt`.
3. Add the eight files `01-...md` through `08-...md` from this folder as project files.
4. Optional: also add the three `.py` files from the `scripts` folder, so ChatGPT can run the scoring and checking scripts.
5. Start a chat inside the project, for example: "Is my website blocking ChatGPT? It's www.mypractice.com"

## Option C: a custom GPT (ChatGPT Plus and up)

1. Go to **Explore GPTs > Create > Configure**.
2. Name: "AI Visibility Copilot for [Practice Name]".
3. Paste `INSTRUCTIONS.txt` into **Instructions**.
4. Upload the eight playbook files (and the scripts) under **Knowledge**.
5. Turn on **Web search** and **Code Interpreter & Data Analysis**.
6. Save it as **Only me** (or share it with your team).

## Gemini

Create a **Gem**, paste `INSTRUCTIONS.txt` as its instructions, and add the playbook files.

---

Never paste patient names or anything that identifies a patient into any AI tool.
