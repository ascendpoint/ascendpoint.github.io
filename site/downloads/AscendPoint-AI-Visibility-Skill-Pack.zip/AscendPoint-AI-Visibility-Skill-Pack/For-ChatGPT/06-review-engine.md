# Dental Review Engine

AI tools and Google both read reviews to decide which practices to trust. What matters is a review base that keeps growing (volume and recency), a strong average, and an owner who replies to every review. This skill builds the asking system and writes the replies.

## Part A: The asking system

Produce these for the practice, filled in with its name, link and staff names:

1. **Who asks:** one named person per shift owns it (usually the person at checkout), not "everyone"
2. **The chairside or checkout script** (15 seconds): ask how the visit went, listen, then ask every patient for a review, whatever they said. Example: "How did everything go today? ... Thank you. Reviews help other families in [city] find us. We'll text you the link in a bit; it takes about a minute."
3. **The text** (send within two hours of the visit, only to patients who opted in to texts): under 160 characters, practice name, the direct review link, no incentive
4. **The email** (backup, next morning): three short lines plus the link
5. **The weekly number to watch:** new reviews this week, average rating, and percentage replied to

Policy rules the scripts must follow:
- **Ask every patient.** Do not screen for happy patients first and only ask them ("review gating"). Google prohibits it and the FTC's 2024 rule on consumer reviews prohibits suppressing negative reviews.
- **No incentives** of any kind for reviews (discounts, raffles, gift cards).
- Staff and family do not review the practice.

## Part B: Replying to reviews

Ask the user to paste the reviews (reviewer first name, stars, text), and once per practice: the practice name, the city, and the office manager's name and direct phone for the "please call" line. Write one reply per review.

**HIPAA rule, every time:** a reply must never confirm that the reviewer is or was a patient, and never mention a visit, a treatment, a date, a provider who treated them, or any detail of their care, even if the reviewer mentioned it first. Thank them for the words, speak about the practice in general, and take anything specific offline.

Reply patterns:

- **5 stars:** thank them by first name, echo one adjective-level theme only (kind, welcoming, calm, on time), invite others in [city], under 50 words. Never repeat the provider's name, the procedure, the timing or the outcome from the review, even though they wrote it. Vary wording; never paste the same reply twice.
- **3 to 4 stars:** thank them, acknowledge the general concern without confirming details, say what the practice does in general, invite them to call the office manager directly by name and number.
- **1 to 2 stars:** stay calm and brief. Do not argue, explain, or reference any visit. One sentence about what the practice values on that general topic, without confirming anything happened (for example "Being on time and making billing easy to understand both matter to us."), then: "We'd like to talk with you directly. Please call [manager] at [phone]." Vary the wording across replies. Flag it for the owner.
- **Looks fake or from someone who was never seen:** never say "you are not a patient" or "we have no record of you"; both disclose who is or isn't a patient. Default reply: "Thank you for the feedback. This doesn't reflect how we work, and we'd welcome a conversation. Please call [manager] at [phone]." Flag it as suspected fake and tell the owner they can report it to Google from the Business Profile (Reviews > the review > Report).

Output: a table with reviewer, stars, the reply, and a flag column (needs owner attention / suspected fake / fine to post). The owner or office manager posts the replies.

## Part C: Weekly batch

The user can schedule this every Friday: "Draft replies to this week's new Google reviews with the dental-review-engine skill." Replying within 48 hours keeps the profile active and recent.
