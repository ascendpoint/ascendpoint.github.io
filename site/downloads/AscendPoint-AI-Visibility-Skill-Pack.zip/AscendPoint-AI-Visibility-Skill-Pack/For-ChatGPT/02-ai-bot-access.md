# Dental AI Bot Access Check

A practice cannot be recommended by AI if AI is not allowed to read its website. Many dental sites block AI bots by accident, through an old robots.txt, a security plugin, or a CDN setting such as Cloudflare's "Block AI bots". This skill finds that, fixes it, and adds an llms.txt file.

## Step 1: Get the domain

Ask for the practice website if you do not have it. Use the root domain (https://www.example.com).

## Step 2: Check robots.txt and llms.txt

**With code execution and internet access**, run:

```
python3 check_ai_access.py https://www.example.com
```

It reads `/robots.txt`, tests every bot in `assets/ai-bots.md` against the homepage (add public pages with `--paths / /dental-implants/`; never pass private paths like /wp-admin/, which are supposed to be blocked), lists any other bots the file blocks, checks for `/llms.txt`, and prints a pass/fail table plus a plain-English verdict. Exit code 1 only means "an AI search bot is blocked"; the report is still complete.

**If the script cannot reach the site** (no network), ask the user to open `https://their-site.com/robots.txt` in a browser and paste the text, save it to a file, and run:

```
python3 check_ai_access.py https://www.example.com --robots-file robots.txt
```

**Without code execution**, read the robots.txt yourself using the rules in `assets/ai-bots.md`. The red flags are `Disallow: /` under `User-agent: *` or under any AI bot by name.

## Step 3: Explain what you found in plain words

Write for an office manager, not a developer. For example: "Your website tells ChatGPT's search bot to stay out of the whole site. That one line hides you from ChatGPT's answers." Also say what is fine.

Note the limits honestly:
- robots.txt is a request. A firewall or CDN can still block bots even when robots.txt allows them. If the robots file looks fine but the practice never shows up in AI answers, ask whoever manages the site to check the CDN or security plugin for an AI bot block.
- Blocking training bots (GPTBot, ClaudeBot, Google-Extended, CCBot) is a business choice some practices make on purpose. If they are already blocked, keep them blocked and say so; the owner decides. Search and user bots (OAI-SearchBot, ChatGPT-User, Claude-SearchBot, Claude-User, PerplexityBot, Googlebot, Bingbot) are what put a practice into AI answers. Only those need unblocking.
- A bot not listed in `assets/ai-bots.md`: leave its rules as the owner set them, and mention it.

## Step 4: Write the fixed robots.txt

Start from the practice's current file and change only what is needed: remove the rules that block AI search and user bots, and keep every rule that protects private areas (admin, patient portal, form handlers, carts). Follow the notes in `assets/robots-template.txt`; in particular, do not add separate "welcome" groups for AI bots, because a bot with its own group stops following the `User-agent: *` rules. Keep the `Sitemap:` line, and add one if it is missing. If you cannot see the sitemap URL, ask for it, or put the likely default in with a `# CONFIRM` comment (WordPress with Yoast: `/sitemap_index.xml`; WordPress core: `/wp-sitemap.xml`; Squarespace and Wix: `/sitemap.xml`).

## Step 5: Write llms.txt

llms.txt is a short Markdown file at the site root that tells AI tools what the practice is and which pages matter. Fill in `assets/llms-template.md` from the practice's real website content:

- Use only facts you can see on the site or that the user gives you. Never invent services, prices, doctors, insurance plans, awards or page URLs.
- If you cannot read the site, fill in only what the user told you, mark everything else `[CONFIRM: ...]`, and say clearly that the file is a draft that is not ready to upload until every `[CONFIRM]` is filled.
- Link the pages that answer patient questions best: services, pricing or financing, insurance, new patients, doctors, contact.
- Keep it under about 60 lines.

## Step 6: Hand-off

Give the user:
1. The verdict (one paragraph)
2. The fixed robots.txt (complete file, ready to paste)
3. The llms.txt (complete file to upload to the site root as `llms.txt`, or a clearly labeled draft if it still has `[CONFIRM]` items)
4. A two-line note they can forward to whoever manages the website: what to upload and where, and to check the CDN/security plugin for AI bot blocking

Never change a live website yourself. The practice's web person uploads the files.


---

## Attached file: assets/ai-bots.md


# AI bots and robots.txt tokens (checked October 2026)

Any bot not in this table: leave its rules as the owner set them.


| Token | Company | What it does | Recommendation for a dental practice |
|---|---|---|---|
| OAI-SearchBot | OpenAI | Indexes pages for ChatGPT search answers | Allow |
| ChatGPT-User | OpenAI | Fetches a page when a ChatGPT user asks about it | Allow |
| GPTBot | OpenAI | Collects content that may train OpenAI models | Owner's choice (allowing is fine for public marketing pages) |
| Claude-SearchBot | Anthropic | Indexes pages for Claude's search answers | Allow |
| Claude-User | Anthropic | Fetches a page when a Claude user asks about it | Allow |
| ClaudeBot | Anthropic | Collects content that may train Claude models | Owner's choice |
| PerplexityBot | Perplexity | Indexes pages for Perplexity answers | Allow |
| Perplexity-User | Perplexity | Fetches a page for a Perplexity user | Allow |
| Googlebot | Google | Google Search, including AI Overviews and AI Mode | Allow (blocking it removes you from Google) |
| Google-Extended | Google | Control token for Gemini training and some grounding; does not affect Google Search | Owner's choice; allowing helps Gemini answers |
| Bingbot | Microsoft | Bing index, which feeds Microsoft Copilot and other assistants | Allow |
| Applebot | Apple | Siri, Spotlight, Safari and Apple Intelligence answers | Allow |
| Applebot-Extended | Apple | Control token for Apple model training | Owner's choice |
| meta-externalagent | Meta | Meta AI training and features | Owner's choice |
| meta-externalfetcher | Meta | Fetches a page for a Meta AI user | Allow |
| CCBot | Common Crawl | Open web archive used to train many AI models | Owner's choice |
| Bytespider | ByteDance | Training for ByteDance AI products | Owner's choice |
| DuckAssistBot | DuckDuckGo | DuckDuckGo's AI answers | Allow |
| Amazonbot | Amazon | Alexa and Amazon answers | Allow |

Notes:
- User-triggered fetchers (ChatGPT-User, Claude-User, Perplexity-User) may not follow robots.txt, because a person asked for the page. Blocking them reliably happens at the firewall or CDN, which is also where accidental blocks hide.
- Google-Extended and Applebot-Extended are permission tokens, not separate crawlers. They will not show up in server logs.

## How to read a robots.txt

- Rules are grouped under one or more `User-agent:` lines. `*` means every bot without its own group.
- A bot follows only the most specific group that names it. If `GPTBot` has its own group, the `*` group no longer applies to GPTBot.
- `Disallow: /` closes the whole site to that group. `Disallow:` with nothing after it closes nothing.
- `Allow:` opens a path inside a closed one. The longest matching rule wins.
- Red flags: `Disallow: /` under `*`, or under any search or user bot above.


---

## Attached file: assets/llms-template.md


# [Practice Name]

> [Practice Name] is a [general / cosmetic / family / pediatric] dental practice in [City, State] led by [Dr. Full Name, DDS/DMD]. We serve patients from [neighborhoods or nearby towns] and offer [3 to 5 core services]. [One sentence on what makes the practice different, in plain words, only if true.]

- Address: [street, city, state, ZIP]
- Phone: [phone, same format as Google Business Profile]
- Hours: [hours, identical to Google Business Profile]
- New patients: [accepting / waitlist]; [insurance accepted or "in-network with ..."]; [financing or membership plan if offered]
- Languages: [if relevant]

## Services

- [Dental Implants](https://www.example.com/dental-implants/): what implants are, cost range, timeline and recovery
- [Invisalign](https://www.example.com/invisalign/): who is a candidate, cost, how long treatment takes
- [Emergency Dentistry](https://www.example.com/emergency-dentist/): same-day visits and what to do before you arrive
- [Service](URL): one-line description

## For patients

- [New Patients](https://www.example.com/new-patients/): first visit, forms, what to bring
- [Insurance and Financing](https://www.example.com/insurance/): plans accepted, membership plan, payment options
- [Patient Questions](https://www.example.com/faq/): answers to common questions

## About the practice

- [Meet Dr. Name](https://www.example.com/about/): education, credentials, years in practice
- [Reviews](https://www.example.com/reviews/): what patients say
- [Contact and Directions](https://www.example.com/contact/)

## Optional

- [Blog](https://www.example.com/blog/): patient education articles


---

## Attached file: assets/robots-template.txt

```
# robots.txt for [Practice Name]
# Public pages are open to search engines and AI assistants. Private areas stay closed.
#
# How to use this template:
# - Keep every private-path rule from the practice's current file (admin, patient portal, forms, cart).
# - Remove any group that blocks an AI search or answer bot (OAI-SearchBot, ChatGPT-User,
#   Claude-SearchBot, Claude-User, PerplexityBot, Googlebot, Bingbot, Applebot).
# - Do NOT add separate "welcome" groups for AI bots: a bot that has its own group ignores the
#   rules under "User-agent: *", so it would lose your private-path rules.
# - Training bots (GPTBot, ClaudeBot, Google-Extended, CCBot...) are the owner's choice. If the
#   old file blocked them on purpose, keep the optional group below; otherwise delete it.

User-agent: *
Disallow: /wp-admin/
Allow: /wp-admin/admin-ajax.php
Disallow: /patient-portal/
Disallow: /cart/
Disallow: /checkout/

# Optional, owner's choice: block AI *training* only (does not affect AI search answers)
# User-agent: GPTBot
# User-agent: ClaudeBot
# User-agent: CCBot
# Disallow: /

Sitemap: https://www.example.com/sitemap.xml
```
