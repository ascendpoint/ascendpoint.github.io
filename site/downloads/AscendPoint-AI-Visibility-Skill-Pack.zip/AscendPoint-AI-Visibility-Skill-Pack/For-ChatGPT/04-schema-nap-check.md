# Dental Schema + NAP Consistency Check

AI engines recommend practices they can verify. Two things make verification easy: structured data (schema) that tells machines exactly who the practice is, and identical name, address, phone and hours everywhere the practice is listed. When the website and Google Business Profile disagree, the engines cannot tell which to believe.

## Part A: NAP consistency

1. Collect the practice's details from each source. Ask the user to paste what each shows if you cannot fetch it:
   - Website (footer and contact page)
   - Google Business Profile
   - Healthgrades, Yelp, Zocdoc, Facebook, Apple Maps, Bing Places, insurance directories (any they use)
2. Save them as JSON in the shape of `scripts/example_listings.json` and run:
   ```
   python3 nap_check.py listings.json
   ```
   It normalizes formatting (St vs Street, (555) 123-4567 vs 555.123.4567, 9:00 AM vs 9am) and reports only real differences, with the source to fix.
3. Treat Google Business Profile as the master record unless the user says otherwise. Every other listing should match it.

Without code execution, compare the sources yourself in a table and flag every real difference, ignoring pure formatting.

## Part B: Practice schema (Dentist JSON-LD)

1. Collect: legal practice name, website, logo URL, phone, full address, geo coordinates (optional), opening hours, dentists (name, credentials), services, accepted insurance (optional), price range (optional), Google Business Profile URL and social profile URLs for `sameAs`.
2. Save as JSON in the shape of `scripts/example_practice.json` and run:
   ```
   python3 build_schema.py practice.json
   ```
   It outputs a `Dentist` JSON-LD block (schema.org's dental practice type), plus a `FAQPage` block if the file includes `faqs`, and validates required fields. Fix every error it prints.
3. Tell the user where it goes: the homepage `<head>` (or the site's SEO plugin "custom schema" field), and the FAQ block only on the page whose visible FAQ matches it word for word.
4. Tell them to test it with Google's Rich Results Test or the Schema.org validator after it is live.

Without code execution, write the JSON-LD by hand following the field list in `scripts/build_schema.py`, and double-check it is valid JSON.

## Rules

- Use only real details. Never invent ratings, review counts, awards or prices. Do not add `aggregateRating` unless the reviews are shown on that same page.
- Hours in schema must match Google Business Profile exactly, including holiday hours if listed.
- One practice location per `Dentist` block. Multi-location groups get one block per location page.
