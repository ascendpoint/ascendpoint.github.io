# Dental AI Visibility Audit

Measures whether AI tools recommend a dental practice, using the three-pillar method SERP Dental uses on every audit: **presence** (do you show up), **position** (where you land in the answer) and **impact** (are you recommended or just linked). Ends with a 90-day plan.

## Step 1: Collect the inputs

Ask for anything missing, in one message:

- Practice name, website, city/state, and the neighborhoods or ZIP codes it serves
- The 3 to 5 services the practice most wants to grow (for example implants, Invisalign, emergency, cosmetic, pediatric)
- Up to 5 competitors they already watch (optional; the audit will find the ones AI names)
- Which AI tools to test. Default: ChatGPT, Google (AI Overview / AI Mode), Gemini, Perplexity

## Step 2: Build the prompt set

Build 20 prompts (40 for a deeper audit) from `assets/prompt-bank.md`. Mix them:

- 40% transactional ("best implant dentist in [city]")
- 40% informational with the city in it ("how much do implants cost in [city]")
- 20% trust and comparison ("which dentist in [city] has the best reviews for anxious patients")

Every scored prompt must include the city or a neighborhood; a prompt with no location almost never names a practice and only drags the score down. Swap in the real services. Write prompts the way a patient types them, not the way a marketer would.

## Step 3: Run the prompts

**If you have web search in this conversation**, run each prompt yourself and record what a patient would see. Record the engine as your own (for example `claude-websearch`). You cannot query ChatGPT, Gemini or Perplexity from here, so never label your own result as theirs.

**If you do not**, give the user the prompt list as a checklist and ask them to paste each AI answer back (a fresh or logged-out chat for each prompt, location set to the practice's city). Do not guess answers you did not see.

Record one row per prompt per engine in this exact CSV shape (the scoring script reads it):

```
prompt,engine,mentioned,rank,impact,competitors,service,type
"best implant dentist in Plano TX",chatgpt,yes,2,recommended,"Smile Studio; Legacy Dental",implants,transactional
```

- `mentioned`: yes or no
- `rank`: the practice's position among practices named (1 = first named). Leave blank if not mentioned
- `impact`: `recommended` (named as a pick), `cited` (linked or used as a source), `mentioned` (in passing), or `none`
- `competitors`: every other practice named, separated by semicolons
- `service` and `type` (optional): the service the prompt is about and transactional / informational / trust. Fill them in to get the per-service and per-type breakdowns

## Step 4: Score it

Save the rows to `results.csv` and run:

```
python3 score_visibility.py results.csv --practice "Practice Name" --alias "Other Name The Practice Uses"
```

The script prints the AI Visibility Score (0 to 100), each pillar, a per-engine breakdown (plus per-service and per-type when those columns are filled), the competitors AI names most, the prompts where the practice is invisible on every engine, and the prompts it misses on only some engines. Warnings about contradictory rows go to stderr; fix the row and re-run. If code execution is not available, apply the scoring rules in `assets/scoring.md` by hand and show your math.

## Step 5: Diagnose the gaps

For every prompt where the practice was missing or ranked below the top 3, look at what the winning practices have that this one lacks. Check, in this order:

1. **Bot access**: is the site blocking AI crawlers? (Use the `dental-ai-bot-access` skill if it is installed.)
2. **Answer pages**: does the practice have a dedicated page for that service that answers cost, time and "does it hurt" in the first three sentences?
3. **Google Business Profile**: complete categories and services, weekly posts, real photos, hours that match the website
4. **Reviews**: count, recency (last 30 days), star average, and whether the owner replies
5. **Third-party proof**: Healthgrades, Yelp, local press, Reddit or community threads that mention the practice
6. **Entity consistency**: same name, address and phone everywhere

Only state what you actually observed. If you could not check something, say "not checked" rather than guessing.

## Step 6: Deliver the report

Use this structure:

1. **AI Visibility Score**: the number, the band (see `assets/scoring.md`), and one sentence on what it means
2. **The three pillars**: presence %, average position, recommendation rate
3. **Who AI recommends instead**: top competitors with how often each was named
4. **Where you are invisible**: prompts missed on every engine first, then the lowest-scoring services and prompt types (if those columns were filled), then engine-specific misses
5. **Top 5 fixes**, ranked by impact divided by effort, each tied to a specific page, profile or listing
6. **90-day plan** using the template in `assets/90-day-plan.md`, filled in for this practice
7. **Re-test date**: same prompt set in 30 days, so progress is measurable

## Guardrails

- Never paste patient names, chart notes or anything that identifies a patient into an AI tool.
- AI answers vary by day, location and account. Present the score as a baseline to track, not a verdict.
- Do not promise a ranking or a date. AI visibility is earned through many small fixes.
- Name competitors only as AI named them. Do not disparage them.

Method: SERP Dental's AI visibility audit, from Patrick Hounsell's AI search webinars (serpdental.com/blog).


---

## Attached file: assets/90-day-plan.md


# 90-day AI visibility plan (template)

Fill in each line for the practice. Keep the order: access first, then content, then authority.

## Days 1 to 30: foundations

- [ ] AI search bots can read the site: robots.txt allows OAI-SearchBot, ChatGPT-User, Claude-SearchBot, PerplexityBot, Googlebot and Bingbot (training bots like GPTBot and ClaudeBot are the owner's choice)
- [ ] An llms.txt file is live at the site root
- [ ] Name, address, phone and hours match exactly on the website and Google Business Profile
- [ ] Google Business Profile: every service listed, correct categories, 10+ original photos
- [ ] Google Business Profile posts are scheduled, two a week
- [ ] Every patient gets a review link within two hours of the visit (by text if they opted in to texts, otherwise email)

## Days 31 to 60: answer pages

- [ ] One dedicated page per priority service: [services]
- [ ] Each page answers what it is, what it costs and how long it takes in the first three sentences
- [ ] A named dentist with credentials on each page
- [ ] FAQ section with 5 to 8 real patient questions, plus FAQPage schema (it gives AI clean structure to read; Google rarely shows FAQ rich results for practices, so don't expect a ranking jump from the markup alone)
- [ ] Dentist (LocalBusiness) schema on the homepage and contact page

## Days 61 to 90: authority

- [ ] Pull the questions patients actually ask (phone logs, front-desk notes, the prompt bank) and fill the content gaps
- [ ] First quarterly press release (a new service, a new doctor, a community event)
- [ ] One original statistic from the practice published on the site (de-identified, aggregate only)
- [ ] Answer 2 to 3 real questions a week on Reddit or local forums, as a professional, without selling
- [ ] Reply to every review, every week
- [ ] Re-run the AI visibility audit with the same prompts and compare


---

## Attached file: assets/prompt-bank.md


# Prompt bank: what patients ask AI about dentists

Replace [city], [neighborhood], [service] and [insurance]. Every prompt you score must include the city or a neighborhood. Use the city name patients use ("Plano", not "Plano city limits"). Pick a mix: about 40% transactional, 40% informational with local intent, 20% trust and comparison.

## Transactional (ready to book)

1. best dentist in [city]
2. best [service] dentist in [city]
3. dentist near [neighborhood] that takes new patients
4. emergency dentist open now in [city]
5. dentist in [city] open on Saturdays
6. dentist in [city] that takes [insurance]
7. top rated cosmetic dentist in [city]
8. who is the best implant dentist in [city]
9. Invisalign provider near [neighborhood]
10. family dentist in [city] good with kids
11. sedation dentist in [city] for anxious patients
12. affordable dentist in [city] without insurance
13. same day crown dentist in [city]
14. dentist in [city] with payment plans or a membership plan
15. pediatric dentist in [city] with good reviews

## Informational (keep the city in every one)

16. how much do dental implants cost in [city]
17. how much does Invisalign cost in [city]
18. does getting a dental implant hurt? dentists in [city]
19. implant vs bridge: which is better and what does each cost in [city]
20. how long does Invisalign take for adults in [city]
21. is teeth whitening at the dentist worth it in [city]
22. what to do for a broken tooth on a weekend in [city]
23. how much is a root canal without insurance in [city]
24. veneers cost in [city] and how long they last
25. what does a dental membership plan cost in [city]
26. gum disease treatment in [city]: how often should I see a dentist
27. wisdom teeth removal in [city]: cost and recovery time
28. are all-on-4 implants worth it in [city]
29. clear aligners vs braces for teenagers in [city]
30. what happens at a first dental visit at a [city] dentist

## Trust and comparison

31. which dentist in [city] has the best reviews
32. most trusted dentist in [city] for implants
33. dentist in [city] that explains costs upfront
34. best dentist in [city] for nervous adults
35. compare [competitor] and [practice] for Invisalign
36. which [city] dentists do not upsell
37. dentist in [city] recommended on Reddit
38. best reviewed emergency dentist near [neighborhood]
39. independent dentist vs dental chain in [city]
40. who are the leading cosmetic dentists in [state]

## Tips for clean results

- Use a fresh chat for each prompt so earlier answers do not steer later ones.
- Set the location to the practice's city where the tool allows it.
- Record exactly what is shown. Screenshots help when you re-test in 30 days.


---

## Attached file: assets/scoring.md


# How the AI Visibility Score works

Each AI answer (one prompt on one engine) earns 0 to 100 points:

| Part | Points |
|---|---|
| **Presence**: the practice is named at all | 40 |
| **Position**: 1st named 40 · 2nd 32 · 3rd 24 · 4th 16 · 5th 8 · 6th or lower 0 | up to 40 |
| **Impact**: recommended 20 · cited or linked 10 · passing mention 0 | up to 20 |

An answer that does not name the practice scores 0. If a mention has no rank (the practice is named but no list order exists), position counts as 3rd, both for points and for average position. "Linked" is recorded as `cited`.

**AI Visibility Score** = the average of every answer's points.

Pillar read-outs:

- **Presence** = share of answers that name the practice
- **Average position** = mean rank across answers that name it
- **Recommendation rate** = share of mentions where the practice is recommended

## Bands

| Score | Band | What it means |
|---|---|---|
| 0 to 24 | Invisible | AI rarely names you. Patients who ask AI are being sent elsewhere |
| 25 to 49 | Emerging | You show up for some prompts, usually low in the list |
| 50 to 74 | Competitive | You are in the conversation for most prompts |
| 75 to 100 | Leading | AI regularly recommends you first or second |

Most practices score low today. That is a reason to start now, while the bar is low, not a reason to panic.
