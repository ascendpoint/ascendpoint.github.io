#!/usr/bin/env python3
"""Score a dental practice's AI visibility from a CSV of AI answers.

Usage:
    python3 score_visibility.py results.csv --practice "Practice Name" [--json]

CSV columns: prompt, engine, mentioned, rank, impact, competitors [, service, type]
    mentioned   yes/no (also accepts y/n, true/false, 1/0)
    rank        1 = first practice named; blank if not mentioned or no order (counts as 3rd)
    impact      recommended | cited (alias: linked) | mentioned | none
    competitors other practices named, separated by ';'
    service     optional, e.g. implants / invisalign / emergency (adds a per-service breakdown)
    type        optional, e.g. transactional / informational / trust (adds a per-type breakdown)

Options:
    --alias NAME   another name the practice goes by (repeatable); excluded from competitors

Scoring (see assets/scoring.md): presence 40 + position up to 40 + impact up to 20.
Standard library only, so it runs anywhere Python 3.8+ runs.
"""
import argparse
import csv
import json
import sys
from collections import Counter, defaultdict

POSITION_POINTS = {1: 40, 2: 32, 3: 24, 4: 16, 5: 8}
IMPACT_POINTS = {"recommended": 20, "cited": 10, "mentioned": 0, "none": 0, "": 0}
IMPACT_ALIASES = {"linked": "cited", "link": "cited", "source": "cited", "recommend": "recommended"}
UNRANKED_AS = 3
BANDS = [(75, "Leading"), (50, "Competitive"), (25, "Emerging"), (0, "Invisible")]
TRUE = {"yes", "y", "true", "1", "x"}


def parse_bool(value):
    return str(value or "").strip().lower() in TRUE


def parse_rank(value):
    value = str(value or "").strip().lstrip("#")
    if not value:
        return None
    try:
        rank = int(float(value))
    except ValueError:
        return None
    return rank if rank >= 1 else None


def answer_points(row):
    """Points (0-100) for one AI answer."""
    if not row["mentioned"]:
        return 0
    rank = row["rank"] if row["rank"] is not None else UNRANKED_AS
    return 40 + POSITION_POINTS.get(rank, 0) + IMPACT_POINTS.get(row["impact"], 0)


def band(score):
    for floor, name in BANDS:
        if score >= floor:
            return name
    return "Invisible"


def norm(name):
    return " ".join(name.lower().replace("&", "and").split())


def load_rows(path, warnings=None):
    warnings = warnings if warnings is not None else []
    rows = []
    with open(path, newline="", encoding="utf-8-sig") as fh:
        reader = csv.DictReader(fh)
        needed = {"prompt", "engine", "mentioned"}
        headers = {h.strip().lower() for h in (reader.fieldnames or [])}
        missing = needed - headers
        if missing:
            raise ValueError(f"CSV is missing column(s): {', '.join(sorted(missing))}")
        for raw in reader:
            r = {k.strip().lower(): (v or "").strip() for k, v in raw.items() if k}
            if not r.get("prompt"):
                continue
            impact = IMPACT_ALIASES.get(r.get("impact", "").lower(), r.get("impact", "").lower())
            if impact not in IMPACT_POINTS:
                raise ValueError(f"Unknown impact '{impact}' for prompt '{r['prompt']}'. "
                                 "Use recommended, cited, mentioned or none.")
            mentioned = parse_bool(r.get("mentioned"))
            if mentioned and impact in ("none", ""):
                warnings.append(f"'{r['prompt']}' ({r.get('engine')}): mentioned=yes but impact=none; scored as a passing mention")
                impact = "mentioned"
            if not mentioned and impact not in ("none", ""):
                warnings.append(f"'{r['prompt']}' ({r.get('engine')}): mentioned=no but impact={impact}; scored as not mentioned")
            rows.append({
                "prompt": r["prompt"],
                "engine": (r.get("engine") or "unknown").lower(),
                "mentioned": mentioned,
                "rank": parse_rank(r.get("rank")) if mentioned else None,
                "impact": impact if mentioned else "none",
                "competitors": [c.strip() for c in r.get("competitors", "").split(";") if c.strip()],
                "service": (r.get("service") or "").strip().lower(),
                "type": (r.get("type") or "").strip().lower(),
            })
    if not rows:
        raise ValueError("No answers found in the CSV.")
    return rows


def _avg(values):
    return round(sum(values) / len(values), 1) if values else 0.0


def score(rows, practice="", aliases=()):
    points = [answer_points(r) for r in rows]
    mentioned = [r for r in rows if r["mentioned"]]
    ranks = [r["rank"] if r["rank"] is not None else UNRANKED_AS for r in mentioned]
    total = _avg(points)

    def breakdown(key):
        groups = defaultdict(list)
        for r, p in zip(rows, points):
            if r[key]:
                groups[r[key]].append(p)
        return {k: _avg(v) for k, v in sorted(groups.items())}

    me = {norm(n) for n in (practice, *aliases) if n.strip()}
    comp, display = Counter(), {}
    for r in rows:
        for c in r["competitors"]:
            key = norm(c)
            if key in me:
                continue
            display.setdefault(key, c)
            comp[key] += 1

    by_prompt = defaultdict(list)
    for r in rows:
        by_prompt[r["prompt"]].append(r)
    invisible = sorted(p for p, rs in by_prompt.items() if not any(x["mentioned"] for x in rs))
    misses = defaultdict(list)
    for p, rs in by_prompt.items():
        if p in invisible:
            continue
        for x in rs:
            if not x["mentioned"]:
                misses[x["engine"]].append(p)
    return {
        "practice": practice,
        "answers": len(rows),
        "score": total,
        "band": band(total),
        "presence_pct": round(100 * len(mentioned) / len(rows), 1),
        "avg_position": round(sum(ranks) / len(ranks), 2) if ranks else None,
        "recommendation_rate_pct": round(
            100 * sum(1 for r in mentioned if r["impact"] == "recommended") / len(mentioned), 1)
        if mentioned else 0.0,
        "by_engine": breakdown("engine"),
        "by_service": breakdown("service"),
        "by_type": breakdown("type"),
        "top_competitors": [(display[k], n) for k, n in comp.most_common(10)],
        "invisible_prompts": invisible,
        "missed_on_some_engines": {e: sorted(v) for e, v in sorted(misses.items())},
    }


def render(result):
    lines = [
        f"AI Visibility Score{(' for ' + result['practice']) if result['practice'] else ''}: "
        f"{result['score']}/100 ({result['band']})",
        f"Answers scored: {result['answers']}",
        "",
        f"Presence:            {result['presence_pct']}% of answers name the practice",
        f"Average position:    {result['avg_position'] if result['avg_position'] else 'n/a'}",
        f"Recommendation rate: {result['recommendation_rate_pct']}% of mentions are recommendations",
        "",
        "By engine:",
    ]
    lines += [f"  {e:<14} {s}" for e, s in result["by_engine"].items()]
    for key, label in (("by_service", "By service:"), ("by_type", "By prompt type:")):
        if result.get(key):
            lines += ["", label] + [f"  {k:<14} {v}" for k, v in result[key].items()]
    lines += ["", "AI recommends instead (times named):"]
    lines += [f"  {n:>3}  {c}" for c, n in result["top_competitors"]] or ["  (none recorded)"]
    lines += ["", f"Invisible on every engine tested ({len(result['invisible_prompts'])}):"]
    lines += [f"  - {p}" for p in result["invisible_prompts"]] or ["  (none)"]
    if result["missed_on_some_engines"]:
        lines += ["", "Shown on some engines but missing on:"]
        for e, ps in result["missed_on_some_engines"].items():
            lines += [f"  {e}:"] + [f"    - {p}" for p in ps]
    return "\n".join(lines)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("csv")
    ap.add_argument("--practice", default="")
    ap.add_argument("--alias", action="append", default=[], help="another name the practice goes by")
    ap.add_argument("--json", action="store_true", help="print JSON instead of a text report")
    args = ap.parse_args(argv)
    warnings = []
    try:
        result = score(load_rows(args.csv, warnings), args.practice, args.alias)
    except (OSError, ValueError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        return 2
    for w in warnings:
        print(f"WARNING: {w}", file=sys.stderr)
    print(json.dumps(result, indent=2) if args.json else render(result))
    return 0


if __name__ == "__main__":
    sys.exit(main())
