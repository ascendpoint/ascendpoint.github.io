#!/usr/bin/env python3
"""Compare a dental practice's name, address, phone and hours across listings.

Usage:
    python3 nap_check.py listings.json [--master "Google Business Profile"] [--json]

listings.json is a list of sources (see example_listings.json):
  [{"source": "Website", "name": "...", "address": "...", "phone": "...",
    "hours": {"Monday": "8:00 AM - 5:00 PM", "Saturday": "Closed", ...}}, ...]

Formatting differences are ignored (Street/St, Suite/Ste/#, phone punctuation, 9am vs 9:00 AM,
en dashes). Only real differences are reported, each against the master listing.
"""
import argparse
import json
import re
import sys

ABBREV = {
    "street": "st", "avenue": "ave", "boulevard": "blvd", "drive": "dr", "road": "rd", "lane": "ln",
    "parkway": "pkwy", "highway": "hwy", "court": "ct", "place": "pl", "circle": "cir", "suite": "ste",
    "building": "bldg", "north": "n", "south": "s", "east": "e", "west": "w", "northeast": "ne",
    "northwest": "nw", "southeast": "se", "southwest": "sw", "freeway": "fwy", "terrace": "ter",
    "expressway": "expy", "square": "sq", "floor": "fl", "apartment": "apt", "unit": "unit",
}
STATES = {
    "alabama": "al", "alaska": "ak", "arizona": "az", "arkansas": "ar", "california": "ca", "colorado": "co",
    "connecticut": "ct", "delaware": "de", "florida": "fl", "georgia": "ga", "hawaii": "hi", "idaho": "id",
    "illinois": "il", "indiana": "in", "iowa": "ia", "kansas": "ks", "kentucky": "ky", "louisiana": "la",
    "maine": "me", "maryland": "md", "massachusetts": "ma", "michigan": "mi", "minnesota": "mn",
    "mississippi": "ms", "missouri": "mo", "montana": "mt", "nebraska": "ne", "nevada": "nv",
    "new hampshire": "nh", "new jersey": "nj", "new mexico": "nm", "new york": "ny", "north carolina": "nc",
    "north dakota": "nd", "ohio": "oh", "oklahoma": "ok", "oregon": "or", "pennsylvania": "pa",
    "rhode island": "ri", "south carolina": "sc", "south dakota": "sd", "tennessee": "tn", "texas": "tx",
    "utah": "ut", "vermont": "vt", "virginia": "va", "washington": "wa", "west virginia": "wv",
    "wisconsin": "wi", "wyoming": "wy", "district of columbia": "dc",
}
DAYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
DAY_ALIASES = dict({d[:3]: d for d in DAYS}, tues="tuesday", thur="thursday", thurs="thursday")


def norm_name(s):
    s = (s or "").lower().replace("&", " and ")
    s = re.sub(r"\b(llc|pllc|pc|p\.c\.|inc|dds|dmd|pa)\b\.?", " ", s)
    s = re.sub(r"[^a-z0-9 ]", " ", s)
    return " ".join(s.split())


def norm_address(s):
    s = (s or "").lower()
    for full, ab in STATES.items():
        s = re.sub(rf"\b{full}\b", ab, s)
    s = re.sub(r"\b(\d{5})-\d{4}\b", r"\1", s)  # ZIP+4 -> ZIP
    s = s.replace("#", " ste ")
    s = re.sub(r"[^a-z0-9 ]", " ", s)
    words = [ABBREV.get(w, w) for w in s.split()]
    words = [w for w in words if w not in ("usa", "us", "united", "states")]
    return " ".join(words)


def norm_phone(s):
    d = re.sub(r"\D", "", s or "")
    return d[1:] if len(d) == 11 and d.startswith("1") else d


def _to_minutes(t):
    t = t.strip().lower().replace(".", "")
    m = re.fullmatch(r"(\d{1,2})(?::(\d{2}))?\s*(am|pm|a|p)?", t)
    if not m:
        return None
    h, mins, ap = int(m.group(1)), int(m.group(2) or 0), (m.group(3) or "")
    if ap.startswith("p") and h != 12:
        h += 12
    if ap.startswith("a") and h == 12:
        h = 0
    return h * 60 + mins


def norm_hours_value(v):
    v = (v or "").strip().lower()
    if not v or v in ("closed", "close", "none", "-"):
        return "closed"
    if "24" in v and "hour" in v:
        return "24h"
    parts = re.split(r"\s*(?:-|–|—|to)\s*", v)
    if len(parts) != 2:
        return v
    a, b = _to_minutes(parts[0]), _to_minutes(parts[1])
    if a is None or b is None:
        return v
    return f"{a // 60:02d}:{a % 60:02d}-{b // 60:02d}:{b % 60:02d}"


def norm_hours(h):
    out = {d: "not listed" for d in DAYS}
    for k, v in (h or {}).items():
        key = k.strip().lower()
        key = DAY_ALIASES.get(key[:5], DAY_ALIASES.get(key[:3], key))
        if key in out:
            out[key] = norm_hours_value(v)
    return out


def compare(listings, master_name=None):
    if not listings:
        raise ValueError("no listings given")
    master = next((l for l in listings if master_name and l.get("source", "").lower() == master_name.lower()),
                  None) or next((l for l in listings if "google" in l.get("source", "").lower()), listings[0])
    m = {
        "name": norm_name(master.get("name")),
        "address": norm_address(master.get("address")),
        "phone": norm_phone(master.get("phone")),
        "hours": norm_hours(master.get("hours")),
    }
    issues = []
    for l in listings:
        if l is master:
            continue
        src = l.get("source", "unknown")
        for field, fn in (("name", norm_name), ("address", norm_address), ("phone", norm_phone)):
            if l.get(field) in (None, ""):
                issues.append({"source": src, "field": field, "problem": "missing",
                               "found": "", "expected": master.get(field, "")})
            elif fn(l.get(field)) != m[field]:
                issues.append({"source": src, "field": field, "problem": "different",
                               "found": l.get(field), "expected": master.get(field, "")})
        if l.get("hours"):
            h = norm_hours(l["hours"])
            for day in DAYS:
                if h[day] != "not listed" and m["hours"][day] != "not listed" and h[day] != m["hours"][day]:
                    issues.append({"source": src, "field": f"hours ({day.title()})", "problem": "different",
                                   "found": (l["hours"].get(day.title()) or h[day]),
                                   "expected": (master.get("hours", {}).get(day.title()) or m["hours"][day])})
    return master.get("source", "master"), issues


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("listings_json")
    ap.add_argument("--master", help="source name to treat as correct (default: Google Business Profile)")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)
    with open(args.listings_json, encoding="utf-8") as fh:
        listings = json.load(fh)
    master, issues = compare(listings, args.master)
    if args.json:
        print(json.dumps({"master": master, "issues": issues}, indent=2))
    elif not issues:
        print(f"All {len(listings)} listings match {master}. Nice and consistent.")
    else:
        print(f"Checked {len(listings)} listings against {master}. {len(issues)} thing(s) to fix:\n")
        for i in issues:
            if i["problem"] == "missing":
                print(f"- {i['source']}: {i['field']} is missing (should be: {i['expected']})")
            else:
                print(f"- {i['source']}: {i['field']} shows \"{i['found']}\" but {master} says \"{i['expected']}\"")
    return 1 if issues else 0


if __name__ == "__main__":
    sys.exit(main())
