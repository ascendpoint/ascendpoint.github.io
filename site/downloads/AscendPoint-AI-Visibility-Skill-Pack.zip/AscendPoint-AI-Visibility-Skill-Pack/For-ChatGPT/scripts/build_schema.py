#!/usr/bin/env python3
"""Build and validate Dentist + FAQPage JSON-LD for a dental practice.

Usage:
    python3 build_schema.py practice.json            # prints <script> blocks ready to paste
    python3 build_schema.py practice.json --raw      # prints plain JSON

practice.json fields (see example_practice.json):
  required: name, url, telephone, address{street, city, region, postal_code, country}, hours[]
  optional: logo, image, description, geo{lat, lng}, price_range, dentists[{name, credentials, url}],
            services[], insurance[], same_as[], gbp_url, faqs[{question, answer}]
hours entries: {"days": ["Monday","Tuesday"], "opens": "08:00", "closes": "17:00"}
"""
import argparse
import json
import re
import sys

DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]
TIME = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")


def validate(p):
    errors, warnings = [], []
    for key in ("name", "url", "telephone", "address", "hours"):
        if not p.get(key):
            errors.append(f"missing required field: {key}")
    url = p.get("url", "")
    if url and not re.match(r"^https://", url):
        errors.append("url must start with https://")
    addr = p.get("address") or {}
    for key in ("street", "city", "region", "postal_code"):
        if addr and not addr.get(key):
            errors.append(f"address.{key} is missing")
    phone_digits = re.sub(r"\D", "", p.get("telephone", ""))
    if p.get("telephone") and len(phone_digits) not in (10, 11):
        errors.append("telephone should be a 10-digit US number (optionally with leading 1)")
    for i, h in enumerate(p.get("hours") or []):
        bad = [d for d in h.get("days", []) if d not in DAYS]
        if not h.get("days") or bad:
            errors.append(f"hours[{i}].days must be full weekday names, got {h.get('days')}")
        for k in ("opens", "closes"):
            if not TIME.match(str(h.get(k, ""))):
                errors.append(f"hours[{i}].{k} must be 24h HH:MM, got {h.get(k)!r}")
    for i, f in enumerate(p.get("faqs") or []):
        if not f.get("question") or not f.get("answer"):
            errors.append(f"faqs[{i}] needs both question and answer")
    if not p.get("logo"):
        warnings.append("no logo: add the practice logo URL")
    if not p.get("same_as") and not p.get("gbp_url"):
        warnings.append("no same_as / gbp_url: link the Google Business Profile and social profiles")
    if not p.get("dentists"):
        warnings.append("no dentists listed: named dentists help AI verify the practice")
    if "aggregate_rating" in p:
        warnings.append("aggregate_rating ignored on purpose: only mark up ratings shown on the same page")
    return errors, warnings


def format_phone(raw):
    d = re.sub(r"\D", "", raw)
    d = d[1:] if len(d) == 11 and d.startswith("1") else d
    return f"+1-{d[0:3]}-{d[3:6]}-{d[6:10]}" if len(d) == 10 else raw


def dentist_schema(p):
    addr = p["address"]
    node = {
        "@context": "https://schema.org",
        "@type": "Dentist",
        "@id": p["url"].rstrip("/") + "/#practice",
        "name": p["name"],
        "url": p["url"],
        "telephone": format_phone(p["telephone"]),
        "address": {
            "@type": "PostalAddress",
            "streetAddress": addr["street"],
            "addressLocality": addr["city"],
            "addressRegion": addr["region"],
            "postalCode": addr["postal_code"],
            "addressCountry": addr.get("country", "US"),
        },
        "openingHoursSpecification": [
            {"@type": "OpeningHoursSpecification", "dayOfWeek": h["days"],
             "opens": h["opens"], "closes": h["closes"]} for h in p["hours"]
        ],
    }
    for src, dst in (("logo", "logo"), ("image", "image"), ("description", "description"),
                     ("price_range", "priceRange")):
        if p.get(src):
            node[dst] = p[src]
    if p.get("geo"):
        node["geo"] = {"@type": "GeoCoordinates", "latitude": p["geo"]["lat"], "longitude": p["geo"]["lng"]}
    same_as = list(p.get("same_as") or [])
    if p.get("gbp_url"):
        same_as.insert(0, p["gbp_url"])
        node["hasMap"] = p["gbp_url"]
    if same_as:
        node["sameAs"] = same_as
    if p.get("dentists"):
        node["employee"] = [
            {k: v for k, v in {"@type": "Person", "name": d["name"], "jobTitle": "Dentist",
                               "honorificSuffix": d.get("credentials"), "url": d.get("url")}.items() if v}
            for d in p["dentists"]
        ]
    if p.get("services"):
        node["hasOfferCatalog"] = {
            "@type": "OfferCatalog", "name": "Dental services",
            "itemListElement": [{"@type": "Offer", "itemOffered": {"@type": "Service", "name": s}}
                                for s in p["services"]],
        }
    if p.get("insurance"):
        node["paymentAccepted"] = ", ".join(["Cash", "Credit Card"] + [f"{i} insurance" for i in p["insurance"]])
    return node


def faq_schema(faqs):
    return {
        "@context": "https://schema.org",
        "@type": "FAQPage",
        "mainEntity": [
            {"@type": "Question", "name": f["question"].strip(),
             "acceptedAnswer": {"@type": "Answer", "text": f["answer"].strip()}} for f in faqs
        ],
    }


def build(p):
    errors, warnings = validate(p)
    if errors:
        return None, errors, warnings
    blocks = [dentist_schema(p)]
    if p.get("faqs"):
        blocks.append(faq_schema(p["faqs"]))
    return blocks, [], warnings


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("practice_json")
    ap.add_argument("--raw", action="store_true", help="print JSON only, no <script> tags")
    args = ap.parse_args(argv)
    with open(args.practice_json, encoding="utf-8") as fh:
        practice = json.load(fh)
    blocks, errors, warnings = build(practice)
    for w in warnings:
        print(f"WARNING: {w}", file=sys.stderr)
    if errors:
        for e in errors:
            print(f"ERROR: {e}", file=sys.stderr)
        return 1
    for b in blocks:
        text = json.dumps(b, indent=2, ensure_ascii=False)
        print(text if args.raw else f'<script type="application/ld+json">\n{text}\n</script>')
    return 0


if __name__ == "__main__":
    sys.exit(main())
