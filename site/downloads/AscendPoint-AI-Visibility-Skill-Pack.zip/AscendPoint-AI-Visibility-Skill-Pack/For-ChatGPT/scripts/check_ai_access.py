#!/usr/bin/env python3
"""Check whether AI assistants are allowed to read a website (robots.txt + llms.txt).

Usage:
    python3 check_ai_access.py https://www.example.com
    python3 check_ai_access.py https://www.example.com --robots-file robots.txt   # offline
    python3 check_ai_access.py https://www.example.com --paths / /dental-implants/ --json

Exit code: 0 = no AI search/answer bot is blocked, 1 = at least one is blocked (the report still printed
fine), 2 = the site could not be reached.

Only test public paths (default '/'). Private paths like /wp-admin/ are supposed to be blocked.

Parses robots.txt the way RFC 9309 (and Google) do it: a bot obeys only the most specific
group that names it (falling back to '*'), the longest matching rule wins, Allow wins ties,
and '*' / '$' wildcards are supported. Standard library only.
"""
import argparse
import json
import re
import sys
import urllib.error
import urllib.request
from urllib.parse import urlparse

BOTS = [
    # token, company, kind  (kind: search | user | training | control)
    ("OAI-SearchBot", "OpenAI", "search"),
    ("ChatGPT-User", "OpenAI", "user"),
    ("GPTBot", "OpenAI", "training"),
    ("Claude-SearchBot", "Anthropic", "search"),
    ("Claude-User", "Anthropic", "user"),
    ("ClaudeBot", "Anthropic", "training"),
    ("PerplexityBot", "Perplexity", "search"),
    ("Perplexity-User", "Perplexity", "user"),
    ("Googlebot", "Google", "search"),
    ("Google-Extended", "Google", "control"),
    ("Bingbot", "Microsoft", "search"),
    ("Applebot", "Apple", "search"),
    ("Applebot-Extended", "Apple", "control"),
    ("meta-externalagent", "Meta", "training"),
    ("meta-externalfetcher", "Meta", "user"),
    ("CCBot", "Common Crawl", "training"),
    ("Bytespider", "ByteDance", "training"),
    ("DuckAssistBot", "DuckDuckGo", "search"),
    ("Amazonbot", "Amazon", "search"),
]
CRITICAL = {"search", "user"}
UA = "Mozilla/5.0 (compatible; AI-Access-Check/1.0; dental-ai-bot-access skill)"


# ---------- robots.txt parsing (RFC 9309) ----------
def parse_robots(text):
    """Return list of groups: {"agents": [lowercase tokens], "rules": [(allow: bool, path)]}."""
    groups, current, last_was_agent = [], None, False
    for raw in text.splitlines():
        line = raw.split("#", 1)[0].strip()
        if not line or ":" not in line:
            continue
        field, value = line.split(":", 1)
        field, value = field.strip().lower(), value.strip()
        if field == "user-agent":
            if not last_was_agent:
                current = {"agents": [], "rules": []}
                groups.append(current)
            current["agents"].append(value.lower())
            last_was_agent = True
        elif field in ("allow", "disallow"):
            last_was_agent = False
            if current is None:
                continue  # rule before any user-agent: ignored per RFC 9309
            if field == "disallow" and value == "":
                continue  # empty Disallow = allow everything
            current["rules"].append((field == "allow", value))
        else:
            last_was_agent = False  # sitemap, crawl-delay, etc. end an agent run
    return groups


def groups_for(groups, token):
    """Rules that apply to a bot token: every group naming it exactly, else the '*' groups."""
    token = token.lower()
    named = [g for g in groups if token in g["agents"]]
    chosen = named or [g for g in groups if "*" in g["agents"]]
    rules = []
    for g in chosen:
        rules.extend(g["rules"])
    return rules, bool(named)


def _pattern_to_regex(path):
    anchored = path.endswith("$")
    body = path[:-1] if anchored else path
    regex = "".join(".*" if ch == "*" else re.escape(ch) for ch in body)
    return re.compile("^" + regex + ("$" if anchored else ""))


def is_allowed(rules, path):
    best_len, best_allow = -1, True
    for allow, pattern in rules:
        if _pattern_to_regex(pattern).match(path):
            length = len(pattern)
            if length > best_len or (length == best_len and allow):
                best_len, best_allow = length, allow
    return best_allow


# ---------- fetching ----------
def fetch(url, timeout=15):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read(512_000).decode("utf-8", "replace")
            return resp.status, body, resp.headers.get("Content-Type", "")
    except urllib.error.HTTPError as exc:
        return exc.code, "", ""


def check(site, robots_text=None, robots_status=None, paths=("/",), llms_status=None):
    groups = parse_robots(robots_text or "")
    results = []
    for token, company, kind in BOTS:
        rules, named = groups_for(groups, token)
        blocked = [p for p in paths if not is_allowed(rules, p)]
        results.append({
            "bot": token, "company": company, "kind": kind,
            "has_own_rules": named,
            "allowed": not blocked, "blocked_paths": blocked,
        })
    known = {t.lower() for t, _, _ in BOTS}
    other_blocked = []
    for g in groups:
        for agent in g["agents"]:
            if agent != "*" and agent not in known and agent not in other_blocked:
                rules, _ = groups_for(groups, agent)
                if any(not is_allowed(rules, p) for p in paths):
                    other_blocked.append(agent)
    critical_blocked = [r for r in results if r["kind"] in CRITICAL and not r["allowed"]]
    training_blocked = [r for r in results if r["kind"] in ("training", "control") and not r["allowed"]]
    sitemap = bool(re.search(r"(?im)^\s*sitemap\s*:", robots_text or ""))
    return {
        "site": site,
        "robots_status": robots_status,
        "robots_found": bool(robots_text),
        "sitemap_listed": sitemap,
        "llms_txt_status": llms_status,
        "llms_txt_found": llms_status == 200,
        "paths_checked": list(paths),
        "bots": results,
        "critical_blocked": [r["bot"] for r in critical_blocked],
        "training_blocked": [r["bot"] for r in training_blocked],
        "other_blocked": other_blocked,
    }


def verdict(report):
    lines = []
    if report["critical_blocked"]:
        lines.append("PROBLEM: robots.txt blocks AI search or answer bots: "
                     + ", ".join(report["critical_blocked"])
                     + ". These are the bots that put a practice into AI answers. Allow them.")
    else:
        lines.append("GOOD: robots.txt lets the AI search and answer bots read the pages checked.")
    if report["training_blocked"]:
        note = ("NOTE: training/permission tokens blocked: " + ", ".join(report["training_blocked"])
                + ". That is the owner's choice; it does not remove the practice from AI search answers. "
                  "Keep them blocked if that was deliberate.")
        if "Google-Extended" in report["training_blocked"]:
            note += " Allowing Google-Extended can help Gemini use the site."
        lines.append(note)
    if report["other_blocked"]:
        lines.append("NOTE: other bots named and blocked in robots.txt: " + ", ".join(report["other_blocked"])
                     + ". These are not AI search bots we track; leave them as the owner set them.")
    if not report["robots_found"]:
        lines.append("NOTE: no robots.txt found. Bots will assume everything is allowed; add one with a Sitemap line.")
    elif not report["sitemap_listed"]:
        lines.append("FIX: robots.txt has no Sitemap: line. Add one so bots find every page.")
    if report["llms_txt_status"] is None:
        lines.append("NOT CHECKED: llms.txt (offline mode). Open /llms.txt in a browser to check.")
    elif not report["llms_txt_found"]:
        lines.append("FIX: no llms.txt at the site root. Add one (see assets/llms-template.md).")
    else:
        lines.append("GOOD: llms.txt is live.")
    lines.append("Reminder: a firewall, CDN or security plugin can still block AI bots even when robots.txt "
                 "allows them. If AI tools never mention the practice, have the web team check for an "
                 "'AI bot' block there too.")
    return lines


def render(report):
    out = [f"AI access check for {report['site']}", ""]
    out.append(f"{'Bot':<20}{'Company':<12}{'Type':<10}{'Status':<10}Notes")
    for r in report["bots"]:
        status = "ALLOWED" if r["allowed"] else "BLOCKED"
        note = ("blocked: " + ", ".join(r["blocked_paths"])) if r["blocked_paths"] else ""
        if r["has_own_rules"]:
            note = (note + "; " if note else "") + "has its own rules"
        out.append(f"{r['bot']:<20}{r['company']:<12}{r['kind']:<10}{status:<10}{note}")
    out += ["", *verdict(report)]
    return "\n".join(out)


def normalize_site(site):
    if not re.match(r"^https?://", site, re.I):
        site = "https://" + site
    p = urlparse(site)
    return f"{p.scheme}://{p.netloc}"


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("site")
    ap.add_argument("--robots-file", help="read robots.txt from this file instead of the web")
    ap.add_argument("--paths", nargs="+", default=["/"], help="paths to test (default: /)")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args(argv)
    site = normalize_site(args.site)
    llms_status = None
    if args.robots_file:
        with open(args.robots_file, encoding="utf-8") as fh:
            robots_text, robots_status = fh.read(), "file"
    else:
        try:
            status, body, ctype = fetch(site + "/robots.txt")
            robots_text = body if status == 200 and "html" not in ctype.lower() else ""
            robots_status = status
            llms_status, _, _ = fetch(site + "/llms.txt")
        except (urllib.error.URLError, OSError) as exc:
            print(f"Could not reach {site}: {exc}. Re-run with --robots-file after pasting robots.txt "
                  "into a file.", file=sys.stderr)
            return 2
    report = check(site, robots_text, robots_status, tuple(args.paths), llms_status)
    print(json.dumps(report, indent=2) if args.json else render(report))
    return 1 if report["critical_blocked"] else 0


if __name__ == "__main__":
    sys.exit(main())
