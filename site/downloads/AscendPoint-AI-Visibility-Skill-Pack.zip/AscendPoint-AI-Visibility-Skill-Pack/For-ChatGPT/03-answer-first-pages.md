# Answer-First Dental Service Pages

Patients do not ask AI "what is the process of a dental implant". They ask "does it hurt?", "how much is it?" and "how long does it take?". Most dental service pages bury those answers under a description of the procedure and the practice's technology. This skill rebuilds a page so the answers come first, in words an AI engine can lift straight into its reply.

Of all the AI visibility fixes, rewriting existing service pages as answers is usually the most impactful.

## Step 1: Gather the facts (never invent them)

Ask for or collect:

- The current page URL or its text (read it if you can fetch it)
- The treating dentist's name, credentials and years in practice
- Real price range or starting price, and whether insurance, financing or a membership plan applies. If the practice will not publish prices, write an honest range-free answer ("cost depends on ... ; most patients pay ... after insurance; we give a written quote at the consult") and flag it
- Typical timeline and recovery
- What makes this practice's version different (only if true and verifiable)
- The questions the front desk hears most about this treatment

If a fact is missing, write `[CONFIRM: ...]` in the draft. Never make up prices, statistics, credentials, technology or guarantees.

## Step 2: Find the patient questions

Combine three sources, then rank by how often patients ask:
1. Front desk questions from the practice
2. The question list in `assets/question-bank.md` for this treatment
3. If you can search the web, the "People also ask" style questions and what AI answers for "[treatment] cost in [city]"

Pick 5 to 8 questions for the page.

## Step 3: Write the page in this order

Follow `assets/page-template.md`:

1. **H1** with the treatment and city ("Dental Implants in Plano, TX")
2. **Answer block, first three sentences**: what it is, what it costs, how long it takes. Plain words, 40 to 60 words total, no hype
3. **Who you will see**: the named dentist, credentials, one human sentence
4. **Question headings** (H2), each opening with a 40 to 60 word direct answer, then detail
5. **Proof**: real reviews about this treatment (quote only reviews the practice gives you), before-and-after only with consent noted
6. **FAQ** with the remaining questions, 2 to 3 sentences each
7. **Next step**: one call to action (call or book), the phone number written out

Style rules:
- Grade 7 to 8 reading level. Short sentences. Second person ("you").
- Lead with outcomes patients want, not equipment
- Use the city and neighborhoods naturally, never stuffed
- No superlatives you cannot prove ("best", "#1", "painless"). Say "most patients describe it as ..." instead
- No patient names or health details unless the practice confirms written consent

## Step 4: Add FAQPage schema

Produce a JSON-LD `FAQPage` block whose questions and answers match the visible FAQ word for word. If the `dental-schema-nap-check` skill is installed, use its script to generate and validate it. Note for the practice: Google shows FAQ rich results only for some sites, but the markup still helps machines read the page.

## Step 5: Deliver

Give the user:
1. The full rewritten page (ready to paste), with `[CONFIRM: ...]` flags listed at the top
2. The FAQPage JSON-LD
3. A before/after table: old page vs new page on answer-first, named doctor, question headings, FAQ, schema, proof
4. Three internal links the page should get from other pages on the site

Built from SERP Dental's AI search training (serpdental.com/blog).


---

## Attached file: assets/page-template.md


# [Treatment] in [City, State]

[What it is, in one sentence.] [What it costs: a real range or starting price, and how insurance, financing or a membership plan affects it.] [How long it takes, from first visit to finished result, and typical recovery.]

**Your dentist:** Dr. [Full Name], [DDS/DMD], [credential or training relevant to this treatment], [years] years in practice. [One human sentence about how they approach this treatment.]

[Book a consultation](URL) · Call [phone]

## How much does [treatment] cost in [City]?

[40 to 60 word direct answer.] [Then detail: what changes the price, what insurance usually covers, financing or membership options, what the consult includes.]

## Does [treatment] hurt?

[40 to 60 word direct answer, honest and calm.] [Then detail: numbing and sedation options, what most patients report, what recovery feels like.]

## How long does [treatment] take?

[40 to 60 word direct answer.] [Then a short step-by-step timeline: consult, treatment visits, healing, final result.]

## Am I a good candidate for [treatment]?

[40 to 60 word direct answer.] [Who it suits, who might need a different option, and what is checked at the consult.]

## [Treatment] vs [common alternative]

[40 to 60 word direct answer.] [A short comparison table: cost, time, how long it lasts, upkeep.]

## What patients say

> "[Real review about this treatment, quoted exactly.]" [First name or initial], [source, e.g. Google]

## Frequently asked questions

### [Question 6]
[2 to 3 sentence answer.]

### [Question 7]
[2 to 3 sentence answer.]

### [Question 8]
[2 to 3 sentence answer.]

## Ready to talk about [treatment]?

[One sentence.] [Book a consultation](URL) or call [phone]. [Address line, matching Google Business Profile exactly.]


---

## Attached file: assets/question-bank.md


# Patient questions by treatment

Use these as a starting list. The practice's own front desk questions always come first.

## Dental implants
- How much do dental implants cost? Does insurance cover them?
- Does getting an implant hurt?
- How long does the whole implant process take?
- Implant vs bridge vs denture: which is better?
- Am I too old for implants? What if I have bone loss?
- How long do implants last?
- What is All-on-4 and how much does it cost?

## Invisalign / clear aligners
- How much does Invisalign cost? Does insurance help?
- How long does Invisalign take for adults?
- Invisalign vs braces: which works faster?
- Does Invisalign hurt?
- How many hours a day do I have to wear aligners?
- What happens after treatment? Do I need retainers?

## Veneers and cosmetic dentistry
- How much do veneers cost per tooth?
- Porcelain vs composite veneers: what is the difference?
- How long do veneers last?
- Do veneers ruin your natural teeth?
- Can I whiten instead of getting veneers?

## Emergency dentistry
- What counts as a dental emergency?
- What should I do for a knocked-out or broken tooth?
- Can I be seen today? On a weekend?
- How much does an emergency visit cost without insurance?
- Should I go to the ER or a dentist for tooth pain?

## Crowns
- How much does a crown cost?
- Can I get a crown in one day?
- Does getting a crown hurt?
- How long does a crown last?

## Root canals
- Does a root canal hurt?
- How much is a root canal with and without insurance?
- Root canal or extraction: which is better?
- How long is recovery after a root canal?

## Teeth whitening
- In-office vs take-home whitening: what is the difference?
- How long does whitening last?
- Does whitening cause sensitivity?
- How much does professional whitening cost?

## Sedation and anxious patients
- What sedation options do you offer?
- Will I be awake?
- Can someone with dental anxiety get everything done in one visit?
- Is sedation safe? Does it cost extra?

## Pediatric and family
- What age should my child first see a dentist?
- Do you see the whole family in one visit?
- How do you help nervous kids?

## New patients and money
- Are you accepting new patients?
- Which insurance plans do you take?
- Do you offer a membership plan for patients without insurance?
- What happens at the first visit and how long does it take?
