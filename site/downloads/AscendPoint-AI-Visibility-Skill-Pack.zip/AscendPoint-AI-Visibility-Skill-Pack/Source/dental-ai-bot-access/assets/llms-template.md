# [Practice Name]

> [Practice Name] is a [general / cosmetic / family / pediatric] dental practice in [City, State] led by [Dr. Full Name, DDS/DMD]. We serve patients from [neighborhoods or nearby towns] and offer [3 to 5 core services]. [One sentence on what makes the practice different, in plain words, only if true.]

- Address: [street, city, state, ZIP]
- Phone: [phone, same format as Google Business Profile]
- Hours: [hours, identical to Google Business Profile]
- New patients: [accepting / waitlist]; [insurance accepted or "in-network with ..."]; [financing or membership plan if offered]
- Languages: [if relevant]

## Services

- [Dental Implants](https://www.example.com/dental-implants/): what implants are, cost range, timeline and recovery
- [Invisalign](https://www.example.com/invisalign/): who is a candidate, cost, how long treatment takes
- [Emergency Dentistry](https://www.example.com/emergency-dentist/): same-day visits and what to do before you arrive
- [Service](URL): one-line description

## For patients

- [New Patients](https://www.example.com/new-patients/): first visit, forms, what to bring
- [Insurance and Financing](https://www.example.com/insurance/): plans accepted, membership plan, payment options
- [Patient Questions](https://www.example.com/faq/): answers to common questions

## About the practice

- [Meet Dr. Name](https://www.example.com/about/): education, credentials, years in practice
- [Reviews](https://www.example.com/reviews/): what patients say
- [Contact and Directions](https://www.example.com/contact/)

## Optional

- [Blog](https://www.example.com/blog/): patient education articles
