# AI bots and robots.txt tokens (checked October 2026)

Any bot not in this table: leave its rules as the owner set them.


| Token | Company | What it does | Recommendation for a dental practice |
|---|---|---|---|
| OAI-SearchBot | OpenAI | Indexes pages for ChatGPT search answers | Allow |
| ChatGPT-User | OpenAI | Fetches a page when a ChatGPT user asks about it | Allow |
| GPTBot | OpenAI | Collects content that may train OpenAI models | Owner's choice (allowing is fine for public marketing pages) |
| Claude-SearchBot | Anthropic | Indexes pages for Claude's search answers | Allow |
| Claude-User | Anthropic | Fetches a page when a Claude user asks about it | Allow |
| ClaudeBot | Anthropic | Collects content that may train Claude models | Owner's choice |
| PerplexityBot | Perplexity | Indexes pages for Perplexity answers | Allow |
| Perplexity-User | Perplexity | Fetches a page for a Perplexity user | Allow |
| Googlebot | Google | Google Search, including AI Overviews and AI Mode | Allow (blocking it removes you from Google) |
| Google-Extended | Google | Control token for Gemini training and some grounding; does not affect Google Search | Owner's choice; allowing helps Gemini answers |
| Bingbot | Microsoft | Bing index, which feeds Microsoft Copilot and other assistants | Allow |
| Applebot | Apple | Siri, Spotlight, Safari and Apple Intelligence answers | Allow |
| Applebot-Extended | Apple | Control token for Apple model training | Owner's choice |
| meta-externalagent | Meta | Meta AI training and features | Owner's choice |
| meta-externalfetcher | Meta | Fetches a page for a Meta AI user | Allow |
| CCBot | Common Crawl | Open web archive used to train many AI models | Owner's choice |
| Bytespider | ByteDance | Training for ByteDance AI products | Owner's choice |
| DuckAssistBot | DuckDuckGo | DuckDuckGo's AI answers | Allow |
| Amazonbot | Amazon | Alexa and Amazon answers | Allow |

Notes:
- User-triggered fetchers (ChatGPT-User, Claude-User, Perplexity-User) may not follow robots.txt, because a person asked for the page. Blocking them reliably happens at the firewall or CDN, which is also where accidental blocks hide.
- Google-Extended and Applebot-Extended are permission tokens, not separate crawlers. They will not show up in server logs.

## How to read a robots.txt

- Rules are grouped under one or more `User-agent:` lines. `*` means every bot without its own group.
- A bot follows only the most specific group that names it. If `GPTBot` has its own group, the `*` group no longer applies to GPTBot.
- `Disallow: /` closes the whole site to that group. `Disallow:` with nothing after it closes nothing.
- `Allow:` opens a path inside a closed one. The longest matching rule wins.
- Red flags: `Disallow: /` under `*`, or under any search or user bot above.
