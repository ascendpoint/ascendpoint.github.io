---
name: dental-ai-bot-access
description: Check whether a dental practice website lets AI assistants read it (robots.txt rules for GPTBot, OAI-SearchBot, ChatGPT-User, ClaudeBot, Claude-SearchBot, PerplexityBot, Google-Extended and others), check for an llms.txt file, and write a corrected robots.txt and a new llms.txt. Use when someone asks "is my website blocking ChatGPT", wants a robots.txt or llms.txt for a dental or medical practice, or is fixing why AI tools cannot see their site.
---

# Dental AI Bot Access Check

A practice cannot be recommended by AI if AI is not allowed to read its website. Many dental sites block AI bots by accident, through an old robots.txt, a security plugin, or a CDN setting such as Cloudflare's "Block AI bots". This skill finds that, fixes it, and adds an llms.txt file.

## Step 1: Get the domain

Ask for the practice website if you do not have it. Use the root domain (https://www.example.com).

## Step 2: Check robots.txt and llms.txt

**With code execution and internet access**, run:

```
python3 scripts/check_ai_access.py https://www.example.com
```

It reads `/robots.txt`, tests every bot in `assets/ai-bots.md` against the homepage (add public pages with `--paths / /dental-implants/`; never pass private paths like /wp-admin/, which are supposed to be blocked), lists any other bots the file blocks, checks for `/llms.txt`, and prints a pass/fail table plus a plain-English verdict. Exit code 1 only means "an AI search bot is blocked"; the report is still complete.

**If the script cannot reach the site** (no network), ask the user to open `https://their-site.com/robots.txt` in a browser and paste the text, save it to a file, and run:

```
python3 scripts/check_ai_access.py https://www.example.com --robots-file robots.txt
```

**Without code execution**, read the robots.txt yourself using the rules in `assets/ai-bots.md`. The red flags are `Disallow: /` under `User-agent: *` or under any AI bot by name.

## Step 3: Explain what you found in plain words

Write for an office manager, not a developer. For example: "Your website tells ChatGPT's search bot to stay out of the whole site. That one line hides you from ChatGPT's answers." Also say what is fine.

Note the limits honestly:
- robots.txt is a request. A firewall or CDN can still block bots even when robots.txt allows them. If the robots file looks fine but the practice never shows up in AI answers, ask whoever manages the site to check the CDN or security plugin for an AI bot block.
- Blocking training bots (GPTBot, ClaudeBot, Google-Extended, CCBot) is a business choice some practices make on purpose. If they are already blocked, keep them blocked and say so; the owner decides. Search and user bots (OAI-SearchBot, ChatGPT-User, Claude-SearchBot, Claude-User, PerplexityBot, Googlebot, Bingbot) are what put a practice into AI answers. Only those need unblocking.
- A bot not listed in `assets/ai-bots.md`: leave its rules as the owner set them, and mention it.

## Step 4: Write the fixed robots.txt

Start from the practice's current file and change only what is needed: remove the rules that block AI search and user bots, and keep every rule that protects private areas (admin, patient portal, form handlers, carts). Follow the notes in `assets/robots-template.txt`; in particular, do not add separate "welcome" groups for AI bots, because a bot with its own group stops following the `User-agent: *` rules. Keep the `Sitemap:` line, and add one if it is missing. If you cannot see the sitemap URL, ask for it, or put the likely default in with a `# CONFIRM` comment (WordPress with Yoast: `/sitemap_index.xml`; WordPress core: `/wp-sitemap.xml`; Squarespace and Wix: `/sitemap.xml`).

## Step 5: Write llms.txt

llms.txt is a short Markdown file at the site root that tells AI tools what the practice is and which pages matter. Fill in `assets/llms-template.md` from the practice's real website content:

- Use only facts you can see on the site or that the user gives you. Never invent services, prices, doctors, insurance plans, awards or page URLs.
- If you cannot read the site, fill in only what the user told you, mark everything else `[CONFIRM: ...]`, and say clearly that the file is a draft that is not ready to upload until every `[CONFIRM]` is filled.
- Link the pages that answer patient questions best: services, pricing or financing, insurance, new patients, doctors, contact.
- Keep it under about 60 lines.

## Step 6: Hand-off

Give the user:
1. The verdict (one paragraph)
2. The fixed robots.txt (complete file, ready to paste)
3. The llms.txt (complete file to upload to the site root as `llms.txt`, or a clearly labeled draft if it still has `[CONFIRM]` items)
4. A two-line note they can forward to whoever manages the website: what to upload and where, and to check the CDN/security plugin for AI bot blocking

Never change a live website yourself. The practice's web person uploads the files.
