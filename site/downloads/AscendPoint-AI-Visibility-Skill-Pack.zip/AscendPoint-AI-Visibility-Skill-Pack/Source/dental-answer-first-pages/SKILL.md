---
name: dental-answer-first-pages
description: Rewrite or create a dental service page (implants, Invisalign, veneers, emergency, crowns, whitening, sedation and so on) so AI assistants and Google can quote it, with the answer in the first three sentences, a named dentist, real patient questions as headings, an FAQ block and FAQPage schema. Use when a practice wants a service page that shows up in ChatGPT or AI Overviews, asks to "rewrite my implant page", wants FAQs for a dental page, or is doing answer engine optimization (AEO) content.
---

# Answer-First Dental Service Pages

Patients do not ask AI "what is the process of a dental implant". They ask "does it hurt?", "how much is it?" and "how long does it take?". Most dental service pages bury those answers under a description of the procedure and the practice's technology. This skill rebuilds a page so the answers come first, in words an AI engine can lift straight into its reply.

Of all the AI visibility fixes, rewriting existing service pages as answers is usually the most impactful.

## Step 1: Gather the facts (never invent them)

Ask for or collect:

- The current page URL or its text (read it if you can fetch it)
- The treating dentist's name, credentials and years in practice
- Real price range or starting price, and whether insurance, financing or a membership plan applies. If the practice will not publish prices, write an honest range-free answer ("cost depends on ... ; most patients pay ... after insurance; we give a written quote at the consult") and flag it
- Typical timeline and recovery
- What makes this practice's version different (only if true and verifiable)
- The questions the front desk hears most about this treatment

If a fact is missing, write `[CONFIRM: ...]` in the draft. Never make up prices, statistics, credentials, technology or guarantees.

## Step 2: Find the patient questions

Combine three sources, then rank by how often patients ask:
1. Front desk questions from the practice
2. The question list in `assets/question-bank.md` for this treatment
3. If you can search the web, the "People also ask" style questions and what AI answers for "[treatment] cost in [city]"

Pick 5 to 8 questions for the page.

## Step 3: Write the page in this order

Follow `assets/page-template.md`:

1. **H1** with the treatment and city ("Dental Implants in Plano, TX")
2. **Answer block, first three sentences**: what it is, what it costs, how long it takes. Plain words, 40 to 60 words total, no hype
3. **Who you will see**: the named dentist, credentials, one human sentence
4. **Question headings** (H2), each opening with a 40 to 60 word direct answer, then detail
5. **Proof**: real reviews about this treatment (quote only reviews the practice gives you), before-and-after only with consent noted
6. **FAQ** with the remaining questions, 2 to 3 sentences each
7. **Next step**: one call to action (call or book), the phone number written out

Style rules:
- Grade 7 to 8 reading level. Short sentences. Second person ("you").
- Lead with outcomes patients want, not equipment
- Use the city and neighborhoods naturally, never stuffed
- No superlatives you cannot prove ("best", "#1", "painless"). Say "most patients describe it as ..." instead
- No patient names or health details unless the practice confirms written consent

## Step 4: Add FAQPage schema

Produce a JSON-LD `FAQPage` block whose questions and answers match the visible FAQ word for word. If the `dental-schema-nap-check` skill is installed, use its script to generate and validate it. Note for the practice: Google shows FAQ rich results only for some sites, but the markup still helps machines read the page.

## Step 5: Deliver

Give the user:
1. The full rewritten page (ready to paste), with `[CONFIRM: ...]` flags listed at the top
2. The FAQPage JSON-LD
3. A before/after table: old page vs new page on answer-first, named doctor, question headings, FAQ, schema, proof
4. Three internal links the page should get from other pages on the site

Built from SERP Dental's AI search training (serpdental.com/blog).
