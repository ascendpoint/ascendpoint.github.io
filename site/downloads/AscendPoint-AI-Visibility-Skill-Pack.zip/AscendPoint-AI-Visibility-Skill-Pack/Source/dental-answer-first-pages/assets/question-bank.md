# Patient questions by treatment

Use these as a starting list. The practice's own front desk questions always come first.

## Dental implants
- How much do dental implants cost? Does insurance cover them?
- Does getting an implant hurt?
- How long does the whole implant process take?
- Implant vs bridge vs denture: which is better?
- Am I too old for implants? What if I have bone loss?
- How long do implants last?
- What is All-on-4 and how much does it cost?

## Invisalign / clear aligners
- How much does Invisalign cost? Does insurance help?
- How long does Invisalign take for adults?
- Invisalign vs braces: which works faster?
- Does Invisalign hurt?
- How many hours a day do I have to wear aligners?
- What happens after treatment? Do I need retainers?

## Veneers and cosmetic dentistry
- How much do veneers cost per tooth?
- Porcelain vs composite veneers: what is the difference?
- How long do veneers last?
- Do veneers ruin your natural teeth?
- Can I whiten instead of getting veneers?

## Emergency dentistry
- What counts as a dental emergency?
- What should I do for a knocked-out or broken tooth?
- Can I be seen today? On a weekend?
- How much does an emergency visit cost without insurance?
- Should I go to the ER or a dentist for tooth pain?

## Crowns
- How much does a crown cost?
- Can I get a crown in one day?
- Does getting a crown hurt?
- How long does a crown last?

## Root canals
- Does a root canal hurt?
- How much is a root canal with and without insurance?
- Root canal or extraction: which is better?
- How long is recovery after a root canal?

## Teeth whitening
- In-office vs take-home whitening: what is the difference?
- How long does whitening last?
- Does whitening cause sensitivity?
- How much does professional whitening cost?

## Sedation and anxious patients
- What sedation options do you offer?
- Will I be awake?
- Can someone with dental anxiety get everything done in one visit?
- Is sedation safe? Does it cost extra?

## Pediatric and family
- What age should my child first see a dentist?
- Do you see the whole family in one visit?
- How do you help nervous kids?

## New patients and money
- Are you accepting new patients?
- Which insurance plans do you take?
- Do you offer a membership plan for patients without insurance?
- What happens at the first visit and how long does it take?
