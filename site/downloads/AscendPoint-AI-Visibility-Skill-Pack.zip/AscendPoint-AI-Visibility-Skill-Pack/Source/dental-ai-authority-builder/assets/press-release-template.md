FOR IMMEDIATE RELEASE

# [Factual headline: Practice Name + news + City]

## [Optional one-line subhead with the patient benefit]

[CITY, State], [Month Day, Year]: [Practice Name], a [type of] dental practice serving [city and nearby areas], today announced [the news in one sentence]. [Second sentence: what changes for patients, in plain words.]

[Paragraph 2: the details. What, when, who, and how patients can access it. Hours, insurance or financing if relevant.]

"[A real, human quote from the lead dentist about why this matters to patients in the community.]" said Dr. [Full Name], [DDS/DMD], [title] of [Practice Name].

[Paragraph 4: background or context, e.g. how long the practice has served the area, the doctor's training relevant to the news. Only verifiable facts.]

[Optional paragraph 5: a community angle or a second quote.]

### About [Practice Name]

[Practice Name] is a [type] dental practice in [City, State], led by Dr. [Full Name]. The practice offers [3 to 5 core services]. [Practice Name] is located at [street address, city, state, ZIP, identical to Google Business Profile]. To learn more, visit [website] or call [phone].

### Media contact

[Name], [title]
[Phone] · [Email]

###
