---
name: dental-ai-authority-builder
description: Build the third-party authority signals AI assistants look for before recommending a dental practice - a quarterly press release, a page of original de-identified practice statistics, and helpful expert answers on Reddit and local forums - plus a 90-day authority calendar. Use when a practice wants press releases, PR for AI search, original research or stats content, Reddit or community answers, or asks how to make ChatGPT see them as an authority.
---

# AI Authority Builder for Dental Practices

AI engines do not only read your website. They look outside it for proof that the practice is real and trusted: press coverage, original data, expert answers in public question-and-answer threads, and consistent mentions across many sites. This skill creates those signals on a steady rhythm.

Pick the part the user needs, or run all three to build the 90-day calendar at the end.

## Part A: Quarterly press release

1. Find the news. Good triggers: a new dentist or specialist joins, a new treatment or technology, a new location or extended hours, a community event or charity day, a milestone (years open, patients served, if the practice confirms the number), an award with a verifiable source.
2. Write it with `assets/press-release-template.md`: a factual headline with the practice name and city, a dateline, the news in the first paragraph, one quote from the lead dentist, a short "About [Practice]" boilerplate with full name, address, phone and website identical to Google Business Profile.
3. 350 to 500 words. No hype words ("revolutionary", "best"). No patient names or health details.
4. Suggest distribution: a press release distribution service that reaches local news sites, the practice's own website news page, and the local chamber of commerce.

Press releases are written as much for the AI engines as for people: they create several authoritative pages that name the practice, its city and its services together.

## Part B: Original practice statistics

AI engines value original data tied to an authoritative source, and a practicing dentist sharing real numbers is exactly that.

1. Ask what the practice can count from its own records, in aggregate only. Examples: implants placed since opening, average years a patient stays with the practice, most common reason new patients call, share of emergency calls seen same day, most asked question at consults.
2. Turn 3 to 5 numbers into a short web page: "[Practice] by the numbers, [year]". Each stat gets one sentence of context and what it means for patients.
3. Rules: aggregate and de-identified only, nothing that could point to one patient, never paste patient records into an AI tool, and the dentist confirms every number before publishing. Write `[CONFIRM]` beside anything not verified.

## Part C: Expert answers on Reddit and local forums

Reddit and community forums are already in question-and-answer form, which AI engines read easily.

1. Find threads: ask the user's city subreddit and r/askdentists style questions about the practice's priority treatments. If you can search the web, list 5 to 10 recent real threads with links.
2. Draft answers in the dentist's voice: helpful, specific, general education only. Disclose the role honestly ("I'm a dentist in [city]"), never sell, never link to the practice unless the community rules allow it and it is truly useful, never diagnose an individual ("see a dentist in person to know for sure").
3. Follow each community's rules. Check them before posting. A human posts, from their own account.
4. Save the questions people ask: they are the next service-page FAQs (see the `dental-answer-first-pages` skill).

## Part D: 90-day authority calendar

| Weeks | Do this |
|---|---|
| 1 to 2 | Publish the practice statistics page |
| 3 | Send press release #1 |
| Every week | Answer 2 to 3 forum or Reddit questions |
| 6 | Pitch one local story (community event, seasonal tip) to a local outlet |
| 10 | Draft press release #2 for next quarter |
| 12 | Re-run the AI visibility audit and compare |
