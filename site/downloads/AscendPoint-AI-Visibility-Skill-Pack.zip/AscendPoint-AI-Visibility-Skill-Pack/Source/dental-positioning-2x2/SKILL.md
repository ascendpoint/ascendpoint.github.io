---
name: dental-positioning-2x2
description: Find a dental practice's "white space" by comparing its website messaging with nearby competitors on a 2x2 grid (outcome-led vs procedure-led, ownable vs generic), then write sharper headlines and an ownable positioning line. Use when a dentist says every dental website sounds the same, wants to stand out from local competitors, asks for a competitive messaging comparison, a positioning statement, or new homepage headlines.
---

# Dental Positioning 2x2

AI writing tools have made dental websites sound alike: the same stock photos, the same "state-of-the-art technology" and "gentle, caring team". That sameness hurts the brand and the rankings, because both patients and algorithms look for something distinct. This exercise finds the message only this practice can own.

## The two axes

- **Outcome-led vs procedure-led.** Does the site lead with results patients want (eat steak again, smile in photos, no more Sunday-night toothache) or with equipment and care (digital X-rays, gentle team)? Patients already expect good tools and gentle care. That is a baseline, not a reason to choose you.
- **Ownable vs generic.** Could only this practice say its main claim, or could any office down the street put it on their homepage unchanged?

|  | Outcome-led | Procedure-led |
|---|---|---|
| **Ownable** | **White space:** results patients want, in a claim only you can make | Distinct, but about you instead of the patient |
| **Generic** | Patient-focused, but sounds like everyone else | **Sea of sameness:** equipment and care claims |

## Step 1: Gather

- The practice's website (homepage + its most important service page)
- 3 to 5 competitors within 5 to 10 miles. If the user does not know them, ask for the city and, if you can search, find the practices that show up for "[main service] [city]"
- What the practice believes makes it different (doctor background, hours, specialties, the patients they love to treat, guarantees they actually honor)

## Step 2: Score every site

Read each homepage hero, main headline and first screen of the key service page. Quote the main claim word for word. Score:
- Outcome-led: 1 (pure procedure) to 5 (pure outcome)
- Ownable: 1 (any practice could say it) to 5 (only this practice can)

If you cannot load a site, say so and leave it off. Never guess what a site says.

## Step 3: Show the grid

Plot every practice on the 2x2 (a table or a simple chart if you can render one). Then say plainly:
- Where the practice sits today and why
- Which quadrant is crowded
- Where the white space is in this market

## Step 4: Write the way out

1. Mine real proof of difference from the practice's answers: specific training, a niche patient type, a process, hours, a promise they keep, the doctor's story, review themes
2. Write 3 positioning lines, each outcome-led and ownable, built on that proof
3. For the strongest line, write a new homepage hero: headline (under 10 words), subhead (one sentence), and a call to action
4. Rewrite the key service page's opening paragraph to match
5. Flag any claim that needs proof before publishing ("only practice in [city] that ..." must be true)

## Output

1. The scored comparison table with each site's quoted claim
2. The 2x2 grid
3. Three positioning options, the recommended one, and the new hero copy
4. Claims to verify before publishing
