---
name: dental-gbp-weekly-posts
description: Draft a dental practice's Google Business Profile posts every week (two a week, about eight a month) in the practice's voice, rotating topics, each answering a real patient question with local detail, one call to action and a tracked link to the matching service page, then route them for office manager approval. Use when a dentist or office manager asks for Google Business Profile posts, GBP updates, a monthly GBP calendar, or a recurring Monday posting routine.
---

# Weekly Google Business Profile Posts for Dentists

The Google Business Profile is the biggest driver of local search rankings and local AI answers, and activity and recency matter. This skill drafts the posts so the practice only has to approve them.

## First run: set up the practice profile

Ask once, then reuse the answers (save them in the project or conversation if you can):

- Practice name, city, neighborhoods served, phone
- Website service pages to link (implants, Invisalign, emergency, new patients, and so on)
- The 4 to 6 services they most want to grow this quarter
- Voice: warm and family, premium and cosmetic, or clinical and calm
- Who approves posts (office manager name)
- Their photo library: where original photos live (no stock photos)
- Any offers they are allowed to promote, with exact terms and end dates
- UTM convention (default below)

## Each week: draft two posts

Follow the monthly rotation so topics never repeat back to back:

| Week | Post 1 | Post 2 |
|---|---|---|
| 1 | Service spotlight | Seasonal or local topic |
| 2 | Patient question (FAQ) | Meet the team |
| 3 | Offer or new-patient welcome | Proof: a result or review theme (no patient details) |
| 4 | Insurance and benefits timing | Patient question (FAQ) |

In November and December, week 4 becomes "use your dental benefits before they reset" if the practice takes insurance.

Every post must:
1. Answer a real patient question or share one useful fact, in 80 to 150 words (Google allows 1,500 characters; short reads better)
2. Include a local detail: the city, a neighborhood, a landmark, a local event or season
3. Have exactly one call to action that fits the topic (Book, Call now, Learn more)
4. Link to the matching service page, never the homepage, with tracking:
   `?utm_source=google&utm_medium=organic&utm_campaign=gbp-post&utm_content=<yyyy-mm-dd>-<topic-slug>`
5. Name the photo to use from the practice's library, with a one-line description. Never stock photos
6. Never repeat a topic or angle from the last 8 posts (ask for the recent list if you do not have it)

## Output format

For each post:

```
POST [n] · [Week, Post 1/2] · [Topic type]
Photo: [file name or description from the library]
Button: [Book / Call now / Learn more]
Link: [full URL with UTM]

[Post text]
```

End with: "Ready for [approver]'s review. Nothing goes live until it is approved."

## Recurring use

The user can schedule this skill to run every Monday at 7 AM (for example with a scheduled task in Claude or ChatGPT): "Every Monday at 7 AM, draft this week's two Google Business Profile posts using the dental-gbp-weekly-posts skill and send them to [approver] for approval."

## Rules

- A person approves every post before it is published. Never publish directly.
- No patient names, photos of patients without written consent, or health details.
- No prices or offers the practice has not confirmed in writing; include offer end dates.
- No "best", "#1" or guarantee claims.
- Google's Q&A and messaging features on Business Profiles have been retired, so do not tell the practice to use them.
