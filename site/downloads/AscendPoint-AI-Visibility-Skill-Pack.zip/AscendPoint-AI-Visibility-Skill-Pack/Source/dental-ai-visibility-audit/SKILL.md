---
name: dental-ai-visibility-audit
description: Measure how often AI assistants (ChatGPT, Gemini, Claude, Perplexity, Google AI Overviews) recommend a dental practice, score it on presence, position and impact, name the competitors AI recommends instead, and turn the gaps into a 90-day AI visibility plan. Use when a dentist, office manager or dental marketer asks "does ChatGPT recommend my practice", wants an AI visibility or AEO audit, an AI search score, or a plan to show up in AI answers.
---

# Dental AI Visibility Audit

Measures whether AI tools recommend a dental practice, using the three-pillar method SERP Dental uses on every audit: **presence** (do you show up), **position** (where you land in the answer) and **impact** (are you recommended or just linked). Ends with a 90-day plan.

## Step 1: Collect the inputs

Ask for anything missing, in one message:

- Practice name, website, city/state, and the neighborhoods or ZIP codes it serves
- The 3 to 5 services the practice most wants to grow (for example implants, Invisalign, emergency, cosmetic, pediatric)
- Up to 5 competitors they already watch (optional; the audit will find the ones AI names)
- Which AI tools to test. Default: ChatGPT, Google (AI Overview / AI Mode), Gemini, Perplexity

## Step 2: Build the prompt set

Build 20 prompts (40 for a deeper audit) from `assets/prompt-bank.md`. Mix them:

- 40% transactional ("best implant dentist in [city]")
- 40% informational with the city in it ("how much do implants cost in [city]")
- 20% trust and comparison ("which dentist in [city] has the best reviews for anxious patients")

Every scored prompt must include the city or a neighborhood; a prompt with no location almost never names a practice and only drags the score down. Swap in the real services. Write prompts the way a patient types them, not the way a marketer would.

## Step 3: Run the prompts

**If you have web search in this conversation**, run each prompt yourself and record what a patient would see. Record the engine as your own (for example `claude-websearch`). You cannot query ChatGPT, Gemini or Perplexity from here, so never label your own result as theirs.

**If you do not**, give the user the prompt list as a checklist and ask them to paste each AI answer back (a fresh or logged-out chat for each prompt, location set to the practice's city). Do not guess answers you did not see.

Record one row per prompt per engine in this exact CSV shape (the scoring script reads it):

```
prompt,engine,mentioned,rank,impact,competitors,service,type
"best implant dentist in Plano TX",chatgpt,yes,2,recommended,"Smile Studio; Legacy Dental",implants,transactional
```

- `mentioned`: yes or no
- `rank`: the practice's position among practices named (1 = first named). Leave blank if not mentioned
- `impact`: `recommended` (named as a pick), `cited` (linked or used as a source), `mentioned` (in passing), or `none`
- `competitors`: every other practice named, separated by semicolons
- `service` and `type` (optional): the service the prompt is about and transactional / informational / trust. Fill them in to get the per-service and per-type breakdowns

## Step 4: Score it

Save the rows to `results.csv` and run:

```
python3 scripts/score_visibility.py results.csv --practice "Practice Name" --alias "Other Name The Practice Uses"
```

The script prints the AI Visibility Score (0 to 100), each pillar, a per-engine breakdown (plus per-service and per-type when those columns are filled), the competitors AI names most, the prompts where the practice is invisible on every engine, and the prompts it misses on only some engines. Warnings about contradictory rows go to stderr; fix the row and re-run. If code execution is not available, apply the scoring rules in `assets/scoring.md` by hand and show your math.

## Step 5: Diagnose the gaps

For every prompt where the practice was missing or ranked below the top 3, look at what the winning practices have that this one lacks. Check, in this order:

1. **Bot access**: is the site blocking AI crawlers? (Use the `dental-ai-bot-access` skill if it is installed.)
2. **Answer pages**: does the practice have a dedicated page for that service that answers cost, time and "does it hurt" in the first three sentences?
3. **Google Business Profile**: complete categories and services, weekly posts, real photos, hours that match the website
4. **Reviews**: count, recency (last 30 days), star average, and whether the owner replies
5. **Third-party proof**: Healthgrades, Yelp, local press, Reddit or community threads that mention the practice
6. **Entity consistency**: same name, address and phone everywhere

Only state what you actually observed. If you could not check something, say "not checked" rather than guessing.

## Step 6: Deliver the report

Use this structure:

1. **AI Visibility Score**: the number, the band (see `assets/scoring.md`), and one sentence on what it means
2. **The three pillars**: presence %, average position, recommendation rate
3. **Who AI recommends instead**: top competitors with how often each was named
4. **Where you are invisible**: prompts missed on every engine first, then the lowest-scoring services and prompt types (if those columns were filled), then engine-specific misses
5. **Top 5 fixes**, ranked by impact divided by effort, each tied to a specific page, profile or listing
6. **90-day plan** using the template in `assets/90-day-plan.md`, filled in for this practice
7. **Re-test date**: same prompt set in 30 days, so progress is measurable

## Guardrails

- Never paste patient names, chart notes or anything that identifies a patient into an AI tool.
- AI answers vary by day, location and account. Present the score as a baseline to track, not a verdict.
- Do not promise a ranking or a date. AI visibility is earned through many small fixes.
- Name competitors only as AI named them. Do not disparage them.

Method: SERP Dental's AI visibility audit, from Patrick Hounsell's AI search webinars (serpdental.com/blog).
