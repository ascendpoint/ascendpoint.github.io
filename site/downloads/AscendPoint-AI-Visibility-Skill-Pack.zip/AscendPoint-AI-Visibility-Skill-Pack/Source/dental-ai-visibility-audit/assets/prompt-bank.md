# Prompt bank: what patients ask AI about dentists

Replace [city], [neighborhood], [service] and [insurance]. Every prompt you score must include the city or a neighborhood. Use the city name patients use ("Plano", not "Plano city limits"). Pick a mix: about 40% transactional, 40% informational with local intent, 20% trust and comparison.

## Transactional (ready to book)

1. best dentist in [city]
2. best [service] dentist in [city]
3. dentist near [neighborhood] that takes new patients
4. emergency dentist open now in [city]
5. dentist in [city] open on Saturdays
6. dentist in [city] that takes [insurance]
7. top rated cosmetic dentist in [city]
8. who is the best implant dentist in [city]
9. Invisalign provider near [neighborhood]
10. family dentist in [city] good with kids
11. sedation dentist in [city] for anxious patients
12. affordable dentist in [city] without insurance
13. same day crown dentist in [city]
14. dentist in [city] with payment plans or a membership plan
15. pediatric dentist in [city] with good reviews

## Informational (keep the city in every one)

16. how much do dental implants cost in [city]
17. how much does Invisalign cost in [city]
18. does getting a dental implant hurt? dentists in [city]
19. implant vs bridge: which is better and what does each cost in [city]
20. how long does Invisalign take for adults in [city]
21. is teeth whitening at the dentist worth it in [city]
22. what to do for a broken tooth on a weekend in [city]
23. how much is a root canal without insurance in [city]
24. veneers cost in [city] and how long they last
25. what does a dental membership plan cost in [city]
26. gum disease treatment in [city]: how often should I see a dentist
27. wisdom teeth removal in [city]: cost and recovery time
28. are all-on-4 implants worth it in [city]
29. clear aligners vs braces for teenagers in [city]
30. what happens at a first dental visit at a [city] dentist

## Trust and comparison

31. which dentist in [city] has the best reviews
32. most trusted dentist in [city] for implants
33. dentist in [city] that explains costs upfront
34. best dentist in [city] for nervous adults
35. compare [competitor] and [practice] for Invisalign
36. which [city] dentists do not upsell
37. dentist in [city] recommended on Reddit
38. best reviewed emergency dentist near [neighborhood]
39. independent dentist vs dental chain in [city]
40. who are the leading cosmetic dentists in [state]

## Tips for clean results

- Use a fresh chat for each prompt so earlier answers do not steer later ones.
- Set the location to the practice's city where the tool allows it.
- Record exactly what is shown. Screenshots help when you re-test in 30 days.
