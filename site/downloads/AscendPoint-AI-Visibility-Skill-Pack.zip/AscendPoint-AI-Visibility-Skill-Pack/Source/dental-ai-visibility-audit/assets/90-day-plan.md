# 90-day AI visibility plan (template)

Fill in each line for the practice. Keep the order: access first, then content, then authority.

## Days 1 to 30: foundations

- [ ] AI search bots can read the site: robots.txt allows OAI-SearchBot, ChatGPT-User, Claude-SearchBot, PerplexityBot, Googlebot and Bingbot (training bots like GPTBot and ClaudeBot are the owner's choice)
- [ ] An llms.txt file is live at the site root
- [ ] Name, address, phone and hours match exactly on the website and Google Business Profile
- [ ] Google Business Profile: every service listed, correct categories, 10+ original photos
- [ ] Google Business Profile posts are scheduled, two a week
- [ ] Every patient gets a review link within two hours of the visit (by text if they opted in to texts, otherwise email)

## Days 31 to 60: answer pages

- [ ] One dedicated page per priority service: [services]
- [ ] Each page answers what it is, what it costs and how long it takes in the first three sentences
- [ ] A named dentist with credentials on each page
- [ ] FAQ section with 5 to 8 real patient questions, plus FAQPage schema (it gives AI clean structure to read; Google rarely shows FAQ rich results for practices, so don't expect a ranking jump from the markup alone)
- [ ] Dentist (LocalBusiness) schema on the homepage and contact page

## Days 61 to 90: authority

- [ ] Pull the questions patients actually ask (phone logs, front-desk notes, the prompt bank) and fill the content gaps
- [ ] First quarterly press release (a new service, a new doctor, a community event)
- [ ] One original statistic from the practice published on the site (de-identified, aggregate only)
- [ ] Answer 2 to 3 real questions a week on Reddit or local forums, as a professional, without selling
- [ ] Reply to every review, every week
- [ ] Re-run the AI visibility audit with the same prompts and compare
