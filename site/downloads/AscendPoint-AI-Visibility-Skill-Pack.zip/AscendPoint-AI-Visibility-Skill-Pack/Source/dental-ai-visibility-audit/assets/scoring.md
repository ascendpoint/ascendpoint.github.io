# How the AI Visibility Score works

Each AI answer (one prompt on one engine) earns 0 to 100 points:

| Part | Points |
|---|---|
| **Presence**: the practice is named at all | 40 |
| **Position**: 1st named 40 · 2nd 32 · 3rd 24 · 4th 16 · 5th 8 · 6th or lower 0 | up to 40 |
| **Impact**: recommended 20 · cited or linked 10 · passing mention 0 | up to 20 |

An answer that does not name the practice scores 0. If a mention has no rank (the practice is named but no list order exists), position counts as 3rd, both for points and for average position. "Linked" is recorded as `cited`.

**AI Visibility Score** = the average of every answer's points.

Pillar read-outs:

- **Presence** = share of answers that name the practice
- **Average position** = mean rank across answers that name it
- **Recommendation rate** = share of mentions where the practice is recommended

## Bands

| Score | Band | What it means |
|---|---|---|
| 0 to 24 | Invisible | AI rarely names you. Patients who ask AI are being sent elsewhere |
| 25 to 49 | Emerging | You show up for some prompts, usually low in the list |
| 50 to 74 | Competitive | You are in the conversation for most prompts |
| 75 to 100 | Leading | AI regularly recommends you first or second |

Most practices score low today. That is a reason to start now, while the bar is low, not a reason to panic.
